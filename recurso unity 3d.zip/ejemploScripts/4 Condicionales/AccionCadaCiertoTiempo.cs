﻿using UnityEngine;
using System.Collections;

public class AccionCadaCiertoTiempo : MonoBehaviour {

	public float tiempo;
	public float tiempoMax;
	
	// Update is called once per frame
	void Update () {
	
		// deltaTime asegura que a lo largo de 1 segundo termina sumando 1
		tiempo = tiempo + Time.deltaTime;

		// La sentencia RETURN hace que se deje de ejecutar a partir de ese punto,
		//  nada por debajo de la sentencia RETURN se ejecutará en el frame actual
		if ( tiempo >= tiempoMax ) {
			print ("HOLA :D");
			tiempo = 0;				// Reseteo del contador para que pueda volver a funcionar
		}

	}
}
