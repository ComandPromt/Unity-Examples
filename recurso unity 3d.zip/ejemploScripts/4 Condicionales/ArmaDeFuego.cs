﻿using UnityEngine;
using UnityEngine.UI;

public class ArmaDeFuego : MonoBehaviour {

	// ZONA DE VARIABLES
	public int municionCargador;		// Balas actuales en el cargador
	public int municionCargadorMax;		// Balas máximas que caben (Read Only!!!)
	public int municionMochila;			// Balas que tenemos en la mochila para ir recargando

	public int balasRecarga;			// La usaremos para tener calculadas las balas que
										//  faltan para recargar en cada momento

	public Text textoUI;

	// ZONA DE MÉTODOS
	void Update () {
	
		// TIP: Sabemos que el comportamiento sólo tiene que procesar cambios cuando
		//  pulsamos las teclas, así que vamos a poner un par de condiciones
		//  para comprobar la tecla de DISPARO y la de RECARGA, sólo ejecutaremos
		//  instrucciones cuando se pulse una de esas teclas

		// 1. Si pulsamos Espacio -> Gestión del Disparo
		if ( Input.GetKeyDown ( KeyCode.Space ) ) {
			// 1.1 Si no hay balas en el cargador (Caso absurdo)
			if ( municionCargador <= 0 ) {
				print ( "No hay balas para disparar" );
			}
			// 1.2 Si hay balas en el cargador (Caso fácil)
			if ( municionCargador > 0 ) {
				municionCargador = municionCargador - 1;
				print ( "PAÑUM" );
			}
		}

		// Cálculo de las balas que faltan en el cargador
		balasRecarga = municionCargadorMax - municionCargador;
		textoUI.text = "AMMO " + municionCargador + "/" + municionCargadorMax + " (" + municionMochila + ")";

		// 2. Si pulsamos R -> Gestión de la Recarga
		if ( Input.GetKeyDown ( KeyCode.R ) ) {
			print ( "RECARGAR" );
			// 2.1 Si no hay balas en la mochila (Caso absurdo)
			if (municionMochila <= 0) {
				print ("No hay balas para recargar");
			}
			// 2.2 Si hay balas suficientes para recargar del todo (Caso fácil)
			if ( balasRecarga < municionMochila ) {
				// Recargar del todo y restar a la mochila
			}
			// 2.3 Si hay balas pero no suficientes para recargar del todo (Caso difícil)
			if ( balasRecarga >= municionMochila ) {
				// Recargar lo que se pueda y dejar la mochila a 0
			}
		
		}

	}
		


	// Declarar la variable:
	// public Text textoUI;


	// Dentro del Update hacer:
	// textoUI.text = "AMMO " + balasCargador + "/" + balasMax + " (" + balasMochila + ")";

	// Quedaría en la UI así:
	// AMMO 16/30 (100)
}
