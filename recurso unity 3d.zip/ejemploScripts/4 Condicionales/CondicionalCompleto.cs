﻿using UnityEngine;
using System.Collections;

public class CondicionalCompleto : MonoBehaviour {

	public int contador;
	
	// Update is called once per frame
	void Update () {

		// Calculamos un valor aleatorio para el contador entre 0 y 1000
		if (Input.anyKeyDown) {
			contador = Random.Range (0, 1000);
		}

		if ( (contador >= 0) && (contador < 100) ) {
			print ("Contador por debajo de 100");
		} 
		else if ( (contador >= 100) && (contador < 300) ) {
			print ("Contador entre 100 y 300");
		} 
		else if ( (contador >= 300) && (contador < 600) ) {
			print ("Contador entre 300 y 600");
		} 
		else if ( (contador >= 600) && (contador < 900) ) {
			print ("Contador entre 600 y 900");
		} 
		else {
			print ("Contador por encima de 900, O POR DEBAJO DE 0");
		}

	
	}
}
