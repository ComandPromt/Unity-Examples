﻿using UnityEngine;

public class PruebaCondicionales : MonoBehaviour {

	// Zona de variables
	public float velocidad = 0.05f;
	public float giro = 1f;

	// Update se ejecuta una vez en cada frame, y el frame no se dibuja hasta que Update
	//  termina de ejecutar 
	void Update () {

		// Consejos para trastear con este script
		// 1) Probar diferencia con else y sin else
		// 2) Probar también qué pasa si sumamos a transform.eulerAngles en vez de transform.position !!!
		// 3) En lugar de andar sumando y restando en los vectores de la transform, vamos a utilizar
		//  los métodos de la transform para trasladar y rotar

		if ( Input.GetKey ( KeyCode.UpArrow ) ) {
			// transform.position = transform.position + new Vector3 ( 0 , 0 , velocidad );
			transform.Translate ( new Vector3 ( 0 , 0 , velocidad ) );
		}
		else if ( Input.GetKey ( KeyCode.DownArrow ) ) {
			// transform.position = transform.position + new Vector3 ( 0 , 0 , -velocidad );
			transform.Translate ( new Vector3 ( 0 , 0 , -velocidad ) );
		}

		if ( Input.GetKey ( KeyCode.LeftArrow ) ) {
			// transform.eulerAngles = transform.eulerAngles + new Vector3 ( 0 , -giro , 0 );
			transform.Rotate ( new Vector3 ( 0 , -giro , 0 ) );
		}
		else if ( Input.GetKey ( KeyCode.RightArrow ) ) {
			//transform.eulerAngles = transform.eulerAngles + new Vector3 ( 0 , giro , 0 );
			transform.Rotate ( new Vector3 ( 0 , giro , 0 ) );
		}

		if ( Input.GetKey ( KeyCode.LeftShift ) ) {
			// transform.eulerAngles = transform.eulerAngles + new Vector3 ( 0 , -giro , 0 );
			transform.Rotate ( new Vector3 ( giro , 0 , 0 ) );
		}
		else if ( Input.GetKey ( KeyCode.LeftControl ) ) {
			//transform.eulerAngles = transform.eulerAngles + new Vector3 ( 0 , giro , 0 );
			transform.Rotate ( new Vector3 ( -giro , 0 , 0 ) );
		}

		if ( Input.GetKey ( KeyCode.Q ) ) {
			// transform.eulerAngles = transform.eulerAngles + new Vector3 ( 0 , -giro , 0 );
			transform.Rotate ( new Vector3 ( 0 , 0 , -giro ) );
		}
		else if ( Input.GetKey ( KeyCode.E ) ) {
			//transform.eulerAngles = transform.eulerAngles + new Vector3 ( 0 , giro , 0 );
			transform.Rotate ( new Vector3 ( 0 , 0 , giro ) );
		}
	}


}
