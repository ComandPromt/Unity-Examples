﻿using UnityEngine;
using System.Collections;

public class ContadorSubeBaja : MonoBehaviour {

	public int contador = 0;
	public bool subiendo = true;
	
	// Update is called once per frame
	void Update () {

		// 2. Si está bajando
		if ( subiendo == false ) {
			//  2.1 Restamos al contador
			contador = contador - 1;
			//  2.2 Si el contador baja de 0 pondremos subiendo a true
			if ( contador <= 0 ) {
				subiendo = true;
			}
		}

		// 1. Si está subiendo
		else if ( subiendo == true ) {
			//	1.1 Sumamos al contador
			contador = contador + 1;
			//  1.2 Si el contador pasa de 10 pondremos subiendo a false
			if ( contador >= 10 ) {
				subiendo = false;
			}
		}

		// Nos la jugamos, si toma valores erróneos destruimos el objeto :D :D :D
		if ( ( contador == -1 ) || ( contador == 11 ) ) {
			Destroy ( gameObject );
		}

	}

}
