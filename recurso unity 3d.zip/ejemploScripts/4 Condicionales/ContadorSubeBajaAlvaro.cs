﻿using UnityEngine;
using System.Collections;

public class ContadorSubeBajaAlvaro : MonoBehaviour {

	public int contador;
	public bool subiendo;
	
	// Update is called once per frame
	void Update () {
	
		// Comprobamos el estado, y sumamos o restamos al contador
		if ( subiendo == true ) {
			contador = contador + 1;
		}
		if ( subiendo == false ) {
			contador = contador - 1;
		}

		// Comprobamos el contador, y cambiamos el estado a true o false
		if ( contador == 10 ) {
			subiendo = false;
		}
		if ( contador == 0 ) {
			subiendo = true;
		}

	}
}
