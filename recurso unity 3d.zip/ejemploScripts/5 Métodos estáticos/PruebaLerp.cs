﻿using UnityEngine;
using System.Collections;

public class PruebaLerp : MonoBehaviour {

	public float vida;
	public float vidaMax;
	public float vidaObjetivo;
	public float dano;
	public float porcentajeAcercamiento;

	// Update is called once per frame
	void Update () {
	
		if ( Input.GetKeyDown (KeyCode.V) ) {
			
			dano = Random.Range ( 0 , 0.5f * vida );

			vidaObjetivo = vida - dano;
			if ( vidaObjetivo < 0 ) {
				vidaObjetivo = 0;
			}

		}
			
		vida = Mathf.Lerp ( vida , vidaObjetivo , porcentajeAcercamiento );

		transform.localScale = new Vector3 ( vida / vidaMax , 1 , 1 );

	}

}
