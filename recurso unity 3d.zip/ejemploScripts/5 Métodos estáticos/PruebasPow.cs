﻿using UnityEngine;
using System.Collections;

public class PruebasPow : MonoBehaviour {

	public int nivelActual;
	public int nivelMaximo;
	
	// Update is called once per frame
	void Update () {

		nivelMaximo = (int)Mathf.Pow ( nivelActual , 2 );

	}

}
