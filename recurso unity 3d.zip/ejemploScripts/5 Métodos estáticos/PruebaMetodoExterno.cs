﻿using UnityEngine;
using System.Collections;

public class PruebaMetodoExterno : MonoBehaviour {

	public PruebaCondicionales script;
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey (KeyCode.Space)) {
			script.transform.Translate ( Vector3.up );
		}
	}

}
