﻿using UnityEngine;
using System.Collections;

public class PruebaStatic2 : MonoBehaviour {

	public bool estado;
	public string tecla;
	public KeyCode codigoTecla;

	public float eje;

	public float resultado;
	public float valorBase;
	public float valorExponente;

	public UnityEngine.UI.Text texto;
	
	// Update is called once per frame
	void Update () {
		estado = Input.GetKey ( codigoTecla );
		eje = Input.GetAxis ("lol");

		// Elevamos un valor a un exponente que decrece un 1% por frame
		resultado = Mathf.Pow ( valorExponente , valorExponente );
		valorExponente = valorExponente * 0.99f;
		texto.text = "R: " + resultado;

		// Si el valor supera la mitad del valor máximo, paramos
		if (resultado > (float.MaxValue / 2f)) {
			Destroy (gameObject);
		}

	}
}
