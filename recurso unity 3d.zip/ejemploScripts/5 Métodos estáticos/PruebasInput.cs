﻿using UnityEngine;
using System.Collections;

public class PruebasInput : MonoBehaviour {

	public bool estadoTecla;
	public bool estadoClic;
	public float valorEje;
	
	// Update is called once per frame
	void Update () {
	
		// Podemos elegir cualquier tecla de la clase KeyCode
		estadoTecla = Input.GetKey ( KeyCode.Space );

		// 0 es clic izqdo, 1 clic dcho, 2 clic central
		estadoClic = Input.GetMouseButton (0);

		// Valor entre -1 y +1 según se pulsen las teclas negativa/positiva definidas
		//  para cada eje en la pestaña Edit/Project Settings/Input
		valorEje = Input.GetAxis ("Horizontal");

	}
}
