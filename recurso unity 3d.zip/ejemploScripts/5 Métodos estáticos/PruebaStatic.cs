﻿using UnityEngine;
using System.Collections;

public class PruebaStatic : MonoBehaviour {

	// ZONA DE VARIABLES
	public static int contadorEstatico;
	public int contadorNormal;

	public Vector3 direccion;
	public Vector3 raton;
	public float calculoRaro;
	public Vector3 vectorLoco;
	
	// ZONA DE MÉTODOS
	void Update () {

		// Con la tecla C sumamos al contador normal y al estático
		if (Input.GetKey (KeyCode.C)) {
			contadorNormal = contadorNormal + 1;
			contadorEstatico = contadorEstatico + 1;
		}

		// Con la tecla P printeamos valores de contador normal y esático
		if (Input.GetKey (KeyCode.P)) {
			Debug.Log ("El estatico vale " + contadorEstatico + " y el normal vale " + contadorNormal);
		}

		// Ejemplos de variables estáticas
		direccion = direccion + Vector3.one;
		Debug.Log ( Input.mousePosition );	// transform.position = Input.mousePosition;
		calculoRaro = Mathf.PI * contadorNormal;
		vectorLoco = Random.onUnitSphere;
		Debug.Log ( "Esto debería valer 1: " + vectorLoco.magnitude);
		transform.position = vectorLoco;

	}
}
