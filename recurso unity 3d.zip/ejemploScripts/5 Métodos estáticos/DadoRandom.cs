﻿using UnityEngine;
using System.Collections;

public class DadoRandom : MonoBehaviour {

	public int dado;
	public float velocidad = 0.05f;
	
	// Update is called once per frame
	void Update () {
	
		if (Input.GetKeyDown (KeyCode.R)) {
			dado = Random.Range ( 1 , 4+1 );
		}

		if (dado == 1) {
			transform.Translate (Vector3.up * velocidad);
		}
		else if (dado == 2) {
			transform.Translate (Vector3.down * velocidad);
		}
		else if (dado == 3) {
			transform.Translate (Vector3.left * velocidad);
		}
		else if (dado == 4) {
			transform.Translate (Vector3.right * velocidad);
		}

	}
}
