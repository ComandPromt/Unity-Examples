﻿using UnityEngine;
using System.Collections;

public class MovimientoLerp : MonoBehaviour {

	public Vector3 posicionObjetivo;
	public float rango = 100;

	// Update is called once per frame
	void Update () {
		
		if (Input.GetKey (KeyCode.M)) {
			posicionObjetivo = Random.insideUnitSphere * rango;
		}


		// Hacemos Lerp desde la posición actual hacia la objetivo,
		//  con un 1% de acercamiento por frame
		transform.position = Vector3.Lerp ( transform.position,
			posicionObjetivo , 0.01f );

	}

}
