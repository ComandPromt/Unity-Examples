﻿using UnityEngine;
using System.Collections;

public class PruebaRaycast : MonoBehaviour {

	public bool resultadoRaycast;
	
	// Update is called once per frame
	void Update () {
		resultadoRaycast = Physics.Raycast ( transform.position, Vector3.down , 1 );
	}
}
