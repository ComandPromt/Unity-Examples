﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ColorAleatorio : MonoBehaviour {

	public Image imagenUI;
	public Color colorObjetivo = Color.white;
	
	// Update is called once per frame
	void Update () {
	
		if (Input.GetKey (KeyCode.C)) {
			colorObjetivo = new Color (Random.value, Random.value, Random.value , 1f );
		}

		imagenUI.color = Color.Lerp ( imagenUI.color , colorObjetivo , 0.01f );

	}
}
