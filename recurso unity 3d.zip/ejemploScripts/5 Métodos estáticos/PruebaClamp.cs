﻿using UnityEngine;
using System.Collections;

public class PruebaClamp : MonoBehaviour {

	public float vida = 500;
	public float vidaMax = 1000;
	public KeyCode teclaAccion = KeyCode.V;
	
	// Update is called once per frame
	void Update () {
	
		if (Input.GetKey ( teclaAccion )) {
			vida = vida + Random.Range ( -vidaMax , vidaMax );
		}

		vida = Mathf.Clamp (vida, 0, vidaMax);

	}

}
