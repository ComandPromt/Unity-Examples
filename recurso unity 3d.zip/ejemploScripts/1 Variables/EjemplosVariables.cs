﻿using UnityEngine;

public class EjemplosVariables : MonoBehaviour {

	// Zona de Variables

	// 1. Variables primitivas, existen en todos los lenguajes de programación
	public int puntosDeVida;
	public float dano;
	public bool tocaSuelo;
	public string nombrePersonaje;

	// 2. Variables estructura, propias de Unity, son varias primitivas juntas
	public Color colorBarraVida;
	public Vector2 direccion2D;
	public Vector3 direccion3D;

	// 3. Variables lista
	public KeyCode teclaSalto;
	public LayerMask objetosAtravesar;
	public Space espacio;
	public ForceMode modoDeFuerza;

	// 4. Variables acceso a componente, hay un tipo por cada componente de Unity
	public Transform posicion;
	public Rigidbody rigidbody;
	public BoxCollider boxCollider;
	public LineRenderer lineRenderer;
	public FixedJoint2D fixedJoint2D;
	public LODGroup lodGroup;
	public GameObject objetoDestino;

	// 5. Variables acceso a recurso de proyecto
	public Texture agujeroBala;
	public AudioClip sonidoDisparo;
	public PhysicMaterial materialRuedas;
	public GameObject prefabProyectil;

}
