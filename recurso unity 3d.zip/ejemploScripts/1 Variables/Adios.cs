﻿using UnityEngine;

public class Adios : BuenosDias {



}
