﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class ControlCambioEscena : MonoBehaviour {

	public int escenaDestino;
	public bool cambioPorTecla;

	// Update is called once per frame
	void Update () {
	
		if ( cambioPorTecla && Input.anyKeyDown )
			CambiarEscena ( );

	}

	public void CambiarEscena ( ) {
		SceneManager.LoadScene ( escenaDestino );
	}

}
