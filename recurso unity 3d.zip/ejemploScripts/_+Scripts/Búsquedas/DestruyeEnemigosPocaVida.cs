﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestruyeEnemigosPocaVida : MonoBehaviour {
	
	// Array de scripts de enemigos donde haremos la búsqueda
	public Enemigo [] scriptsEnemigos;

	// Update is called once per frame
	void Start () {
		
		// Hacemos la búsqueda, múltiple por componente (Enemigo) en toda la escena
		scriptsEnemigos = FindObjectsOfType<Enemigo> ();

		// Foreach para recorrer todo el array de scripts de Enemigo
		foreach ( Enemigo actual in scriptsEnemigos ) {

			// Si vemos que un script tiene vida < 25 destruimos el GameObject al que pertenece
			if ( actual.vida <= 25 ) {
				Destroy ( actual.gameObject );
			}

		}

	}

}
