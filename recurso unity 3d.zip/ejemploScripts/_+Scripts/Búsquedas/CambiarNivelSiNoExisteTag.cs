﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class CambiarNivelSiNoExisteTag : MonoBehaviour {

	public float tiempoComprobacion = 1f;
	public string tagComprobar = "Item";
	public int nivel = 2;

	private float contador = 0f;
	
	// Update se ejecuta en todos los frames
	void Update () {
	
		// Contamos segundos y retornamos si no ha llegado el tiempo de comprobar
		contador += Time.deltaTime;
		if (contador < tiempoComprobacion)
			return;

		// Aquí ya tenemos que hacer la comprobación, si encontramos 0 objetos
		//  hacemos el cambio de nivel
		GameObject [ ] objetos = GameObject.FindGameObjectsWithTag ( tagComprobar );
		if ( objetos.Length == 0 ) {
			SceneManager.LoadScene (nivel);
		}

		// Devolvemos el contador a 0 para que pueda seguir funcionando el tiempo
		//  de comprobación
		contador = 0f;

	}
}
