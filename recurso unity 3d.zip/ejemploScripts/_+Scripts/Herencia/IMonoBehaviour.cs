using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public abstract class IMonoBehaviour : MonoBehaviour, 
	IDragHandler, IBeginDragHandler, IEndDragHandler, IDropHandler, IInitializePotentialDragHandler,
IMoveHandler, IPointerClickHandler, IPointerDownHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler, IScrollHandler,
ICancelHandler, ISelectHandler, IDeselectHandler, IUpdateSelectedHandler, ISubmitHandler
{

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	// touch & drag events
	public virtual void OnBeginDrag (PointerEventData data) {}
	public virtual void OnEndDrag (PointerEventData data) {}
	public virtual void OnDrag (PointerEventData data) {}
	public virtual void OnDrop (PointerEventData data) {}
	public virtual void OnInitializePotentialDrag (PointerEventData data) {}

	// pointer events
	public virtual void (AxisEventData data) {}
	public virtual void OnPointerClick(PointerEventData data) {}
	public virtual void OnPointerDown(PointerEventData data) {}
	public virtual void OnPointerUp(PointerEventData data) {}
	public virtual void OnPointerEnter(PointerEventData data) {}
	public virtual void OnPointerExit(PointerEventData data) {}
	public virtual void OnScroll(PointerEventData data) {}

	// general events
	public virtual void OnCancel(BaseEventData data) {}
	public virtual void OnSelect(BaseEventData data) {}
	public virtual void OnDeselect(BaseEventData data) {}W
	public virtual void OnUpdateSelected(BaseEventData data) {}
	public virtual void OnSubmit(BaseEventData data) {}

}
