﻿using UnityEngine;
using System.Collections;

public class ControladorCharacterController : MonoBehaviour {

	// Configuracion de velocidades
	public float velocidad = 6.0f;
	public float giro = 90.0f;
	public float salto = 8.0f; 
	public float gravedad = 20.0f;

	private Vector3 movimiento = Vector3.zero;
	public CharacterController controladorMovimiento;

	void Update ( ) {

		// Solo respondemos a controles si esta en el suelo
		if ( controladorMovimiento.isGrounded ) {

			// Leo la entrada de datos direccional
			float vertical = Input.GetAxis ( "Vertical" );

			// Calculamos movimiento segun la entrada de datos
			movimiento = new Vector3 ( 0 , 0 , vertical );

			// Convertimos el movimiento en coordenadas locales, por si hemos girado
			movimiento = transform.TransformDirection ( movimiento );

			// Multiplicamos por la velocidad del personaje
			movimiento *= velocidad;

			// Salto
			if ( Input.GetButton ( "Jump" ) ) {
				movimiento.y = salto;
			}
			
		}

		// Si no esta en el suelo aplicamos la gravedad
		else {
			movimiento.y -= gravedad * Time.deltaTime;
		}

		// Giro
		transform.Rotate ( Input.GetAxis ( "Horizontal" ) * Vector3.up * giro * Time.deltaTime );

		// Movimiento final
		controladorMovimiento.Move ( movimiento * Time.deltaTime );

	}

}
