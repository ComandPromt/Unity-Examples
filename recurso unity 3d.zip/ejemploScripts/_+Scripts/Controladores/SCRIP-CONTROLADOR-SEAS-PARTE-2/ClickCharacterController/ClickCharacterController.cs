﻿using UnityEngine;

class ClickCharacterController : MonoBehaviour
{

    float smooth = 0.05f; // Determines how quickly object moves towards position

    private Vector3 targetPosition;
    private Vector3 startPosition;


    void Awake()
    {


        transform.position = new Vector3(110f, 1f, 50f);
    }

    void Update()
    {


        if (Input.GetKey(KeyCode.Mouse1))
        {
            Plane playerPlane = new Plane(Vector3.up, transform.position);
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            float hitdist = 0.0f;


            if (playerPlane.Raycast(ray, out hitdist))
            {
                var targetPoint = ray.GetPoint(hitdist);
                targetPosition = ray.GetPoint(hitdist);
                var targetRotation = Quaternion.LookRotation(targetPoint - transform.position);
                transform.rotation = targetRotation;
            }

        }



        transform.position = Vector3.Lerp(transform.position, targetPosition, Time.maximumDeltaTime * smooth);

    }

}
