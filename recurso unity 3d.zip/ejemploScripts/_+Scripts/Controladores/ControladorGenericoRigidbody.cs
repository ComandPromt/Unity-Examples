// Script: ControladorRigidbody.cs
// Descripción: Controla las fuerzas y torsiones aplicadas a un rigidbody
//  para utilizarlo como controlador general de personajes/vehículos
// Autor: Iván García Subero, TRINIT Asociación de Informáticos de
//  Zaragoza, http://trinit.es, trinit@trinit.es
// Dependencias: Debe ser asignado a un objeto de juego con rigidbody

using UnityEngine;
using System.Collections;

public class ControladorGenericoRigidbody : MonoBehaviour {
	
	// Declaración de variables
	public KeyCode teclaFuerzaX = KeyCode.RightArrow;
	public Vector3 fuerzaX = new Vector3 ( 10.0F , 0.0F , 0.0F );
	
	public KeyCode teclaFuerzaXNegativa = KeyCode.LeftArrow;
	public Vector3 fuerzaXNegativa = new Vector3 ( -10.0F , 0.0F , 0.0F );
	
	public KeyCode teclaFuerzaY = KeyCode.LeftShift;
	public Vector3 fuerzaY = new Vector3 ( 0.0F , 10.0F , 0.0F );
	
	public KeyCode teclaFuerzaYNegativa = KeyCode.LeftControl;
	public Vector3 fuerzaYNegativa = new Vector3 ( 0.0F , -10.0F , 0.0F );
	
	public KeyCode teclaFuerzaZ = KeyCode.UpArrow;
	public Vector3 fuerzaZ = new Vector3 ( 0.0F , 0.0F , 10.0F );
	
	public KeyCode teclaFuerzaZNegativa = KeyCode.DownArrow;
	public Vector3 fuerzaZNegativa = new Vector3 ( 0.0F , 0.0F , -10.0F );
	
	public KeyCode teclaTorsionX = KeyCode.W;
	public Vector3 torsionX = new Vector3 ( 10.0F , 0.0F , 0.0F );
	
	public KeyCode teclaTorsionXNegativa = KeyCode.S;
	public Vector3 torsionXNegativa = new Vector3 ( -1.0F , 0.0F , 0.0F );
	
	public KeyCode teclaTorsionY = KeyCode.D;
	public Vector3 torsionY = new Vector3 ( 0.0F , 1.0F , 0.0F );
	
	public KeyCode teclaTorsionYNegativa = KeyCode.A;
	public Vector3 torsionYNegativa = new Vector3 ( 0.0F , -1.0F , 0.0F );
	
	public KeyCode teclaTorsionZ = KeyCode.Q;
	public Vector3 torsionZ = new Vector3 ( 0.0F , 0.0F , 1.0F );
	
	public KeyCode teclaTorsionZNegativa = KeyCode.E;
	public Vector3 torsionZNegativa = new Vector3 ( 0.0F , 0.0F , -1.0F );
	
	// Update is called once per frame
	void FixedUpdate ( ) {
		
		if ( Input.GetKey ( teclaFuerzaX ) ) {
			rigidbody.AddRelativeForce ( fuerzaX );
		}
		
		if ( Input.GetKey ( teclaFuerzaXNegativa ) ) {
			rigidbody.AddRelativeForce ( fuerzaXNegativa );
		}
		
		if ( Input.GetKey ( teclaFuerzaY ) ) {
			rigidbody.AddRelativeForce ( fuerzaY );
		}
		
		if ( Input.GetKey ( teclaFuerzaYNegativa ) ) {
			rigidbody.AddRelativeForce ( fuerzaYNegativa );
		}
		
		if ( Input.GetKey ( teclaFuerzaZ ) ) {
			rigidbody.AddRelativeForce ( fuerzaZ );
		}
		
		if ( Input.GetKey ( teclaFuerzaZNegativa ) ) {
			rigidbody.AddRelativeForce ( fuerzaZNegativa );
		}
		
		if ( Input.GetKey ( teclaTorsionX ) ) {
			rigidbody.AddRelativeTorque ( torsionX );
		}
		
		if ( Input.GetKey ( teclaTorsionXNegativa ) ) {
			rigidbody.AddRelativeTorque ( torsionXNegativa );
		}
		
		if ( Input.GetKey ( teclaTorsionY ) ) {
			rigidbody.AddRelativeTorque ( torsionY );
		}
		
		if ( Input.GetKey ( teclaTorsionYNegativa ) ) {
			rigidbody.AddRelativeTorque ( torsionYNegativa );
		}
		
		if ( Input.GetKey ( teclaTorsionZ ) ) {
			rigidbody.AddRelativeTorque ( torsionZ );
		}
		
		if ( Input.GetKey ( teclaTorsionZNegativa ) ) {
			rigidbody.AddRelativeTorque ( torsionZNegativa );
		}
	
	}
}
