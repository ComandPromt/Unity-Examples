﻿using UnityEngine;
using System.Collections;

public class CamaraVuelo : MonoBehaviour {

	public Rigidbody rigidbodyNave;
	public Transform pivoteLookAt;
	public float distancia;
	public float altura;
	
	// Update is called once per frame
	void FixedUpdate () {
	
		transform.rotation = rigidbodyNave.transform.rotation;
		transform.position = rigidbodyNave.transform.position;

		transform.Translate ( -rigidbodyNave.velocity.normalized * distancia , Space.World );
		transform.Translate ( rigidbodyNave.transform.up * altura , Space.World );

		transform.LookAt (pivoteLookAt);

	}
}
