﻿// Script: EventoRaycast.cs
// Descripción: Al hacer clic nos indica en consola el nombre del objeto que hay delante
// Autor: Ivan Garcia Subero
// Fecha: 09.04.14
// Licencia: Dominio público
// Dependencias: Ninguna
// Por hacer: Nada

using UnityEngine;
using System.Collections;

public class RaycastNombre : MonoBehaviour {

	// Aqui almacenaremos la informacion del objeto impactado
	private RaycastHit impacto;

	// Update is called once per frame
	void Update ( ) {

		// Solo procesamos si hay clic
		if ( !Input.GetMouseButtonDown ( 0 ) ) return;

		// Lanzamos rayo p'alante y si toca algo escribimos
		if ( Physics.Raycast ( transform.position ,
			transform.forward , out impacto ) ) {
			print ( "Detectado " + impacto.transform.name );
		}

	}

}
