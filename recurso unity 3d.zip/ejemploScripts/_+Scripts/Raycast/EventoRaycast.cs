﻿// Script: EventoRaycast.cs
// Descripción: Al hacer clic nos indica en consola si hay un objeto delante
// Autor: Ivan Garcia Subero
// Fecha: 25.03.14
// Licencia: Dominio público
// Dependencias: Ninguna
// Por hacer: Nada

using UnityEngine;
using System.Collections;

public class EventoRaycast : MonoBehaviour {
	
	// Update is called once per frame
	void Update ( ) {

		// Solo procesamos si hay clic
		if ( !Input.GetMouseButtonDown ( 0 ) ) return;

		// Lanzamos rayo p'alante y si toca algo escribimos
		if ( Physics.Raycast ( transform.position ,
			transform.forward ) ) {
			print ( "Detectado objeto" );
		}

	}

}
