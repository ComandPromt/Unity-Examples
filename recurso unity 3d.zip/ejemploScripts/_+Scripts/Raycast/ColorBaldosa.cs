﻿using UnityEngine;
using System.Collections;

public class ColorBaldosa : MonoBehaviour {

	public string tagComprobar = "Baldosa";
	public Color colorCambio = Color.red;
	public float distanciaRayo = 1.2f;
	
	// Update is called once per frame
	void Update ( ) {
	
		// Variable para almacenar la info del impacto de raycast si lo hay
		RaycastHit infoImpacto;

		// Si el raycast no toca nada, retornamos
		if ( !Physics.Raycast ( transform.position ,
			Vector3.down , out infoImpacto , distanciaRayo ) ) return;

		// Variable para acceder al objeto que hemos tocado
		GameObject objetoTocado = infoImpacto.transform.gameObject;

		// Si el tag del objeto impactado no es el que buscamos, retornamos
		if ( objetoTocado.tag != tagComprobar ) return;

		// Si hemos llegado hasta aqui, es que tenemos debajo la baldosa, coloreamos
		objetoTocado.GetComponent<Renderer> ().material.color = colorCambio;

	}
}
