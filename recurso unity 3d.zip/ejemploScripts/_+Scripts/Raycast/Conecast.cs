﻿using UnityEngine;
using System.Collections;

public class Conecast : MonoBehaviour {

	public float anguloVision = 30f;
	public float distanciaVision = 20f;

	public GameObject objetivo;
	public RaycastHit impacto;

	public bool obstaculo;
	public bool visto = false;
	
	// Update is called once per frame
	void Update ( ) {
	
		// Generamos el vector que nos da la direccion al objetivo
		Vector3 direccion = objetivo.transform.position - transform.position;

		// Si el raycast detecta obstaculo, comprobamos si es el objetivo
		obstaculo = Physics.Raycast ( transform.position , direccion , out impacto , distanciaVision );
		if ( obstaculo ) {

			// Si detectamos un obstaculo que no es el objetivo salimos, no lo estamos viendo
			if ( impacto.transform.gameObject != objetivo ) {
				visto = false;
				return;
			}
		}

		// Si no detectamos nada tambien salimos, no lo estamos viendo
		else {
			visto = false;
			return;
		}

		// Si el raycast no detecta obstaculo, comprobamos que angulo de vision tenemos con el objeto
		float angulo = Vector3.Angle ( direccion , transform.forward );

		// El objeto esta a la vista si el angulo de vision que tenemos con el es menor que el del conecast
		visto = ( angulo < anguloVision );

	}
}
