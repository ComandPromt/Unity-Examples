﻿using UnityEngine;
using System.Collections;

public class ConeCastColor : MonoBehaviour {

	public float angulo = 60f;
	public float distancia = 30f;
	public GameObject objetivo;
	
	// Update is called once per frame
	void Update ( ) {
		Vector3 diferencia = objetivo.transform.position - transform.position;
		if ( !Physics.Raycast ( transform.position , diferencia , distancia ) ) return;
		float anguloActual = Vector3.Angle ( transform.forward , diferencia );
		print ( "El angulo actual es " + anguloActual );
		if ( anguloActual > angulo/2 ) { 
			objetivo.GetComponent<Renderer> ().material.color = Color.white;
		}
		else {
			objetivo.GetComponent<Renderer> ().material.color = Color.red;
		}
	}

}
