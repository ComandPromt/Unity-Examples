﻿using UnityEngine;
using System.Collections;

public class Aerodinamica : MonoBehaviour {

	// Aquí veremos la desviación de velocidad que tiene el rigidbody hacia los lados
	// y hacia arriba/abajo. La calcularemos mediante producto escalar con Dot ( )
	public float desviacionHorizontal;
	public float desviacionVertical;
	public Rigidbody rigidbody;

	void Start ( ) {
		rigidbody = GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void Update () {
	
		// Calculamos si tiene la velocidad desviada hacia X ó hacia Y
		desviacionHorizontal = Vector3.Dot ( rigidbody.velocity , transform.right );
		desviacionVertical = Vector3.Dot ( rigidbody.velocity , transform.up );

		// Aplicamos mayor drag cuanta mayor desviación en esas direcciones
		// (Se puede calibrar multiplicando por un factor)
		rigidbody.drag = Mathf.Abs (desviacionVertical) + Mathf.Abs ( desviacionHorizontal );

	}
}
