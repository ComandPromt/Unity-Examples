﻿// Script: ControladorRigidbody2.cs
// Descripción: Controlador basico de rigidbody, aplicando la fuerza en FixedUpdate
// Autor: Ivan Garcia Subero
// Fecha: 25.03.14
// Licencia: Dominio público
// Dependencias: Debe ser asociado a un objeto con rigidbody
// Por hacer: Nada

using UnityEngine;
using System.Collections;

public class ControladorRigidbody2 : MonoBehaviour {

	public float fuerza = 1;
	public float traccion = 0.5f;

	// Update is called once per frame
	void FixedUpdate ( ) {

		if ( Input.GetKey ( KeyCode.W ) ) {
			rigidbody.AddRelativeForce ( 0 , 0 , fuerza );
		}
		
		if ( Input.GetKey ( KeyCode.A ) ) {
			rigidbody.AddRelativeTorque ( 0 , -traccion ,0);
		}

	}
}
