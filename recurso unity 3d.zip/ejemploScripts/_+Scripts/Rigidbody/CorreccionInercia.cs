﻿using UnityEngine;
using System.Collections;

public class CorreccionInercia : MonoBehaviour {

	public float factor;
	public Rigidbody rigidbody;

	// Update is called once per frame
	void FixedUpdate ( ) {

		// Obtenemos la direccion de la velocidad para corregirla
		Vector3 correccion = rigidbody.velocity;
		correccion = correccion.normalized;

		float magnitud = rigidbody.velocity.magnitude;

		correccion = Vector3.Lerp ( correccion ,
			transform.forward , factor );

		rigidbody.velocity = correccion * magnitud;

	}

}
