﻿using UnityEngine;
using System.Collections;

public class OrientarSegunVelocidad : MonoBehaviour {

	public GameObject objetoConRigidbody;
	private Rigidbody rigidbodyDelObjeto;
	public float suavidad = 0.1f;

	void Start ( ) {
		rigidbodyDelObjeto = objetoConRigidbody.GetComponent<Rigidbody> ();
	}

	// Update is called once per frame
	void FixedUpdate () {
		transform.forward = Vector3.Lerp (
			transform.forward, rigidbodyDelObjeto.velocity.normalized, suavidad);
	}
}
