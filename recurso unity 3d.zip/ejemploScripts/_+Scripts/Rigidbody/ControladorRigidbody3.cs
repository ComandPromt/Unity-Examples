﻿// Script: ControladorRigidbody2.cs
// Descripción: Controlador basico de rigidbody, aplicando la fuerza en FixedUpdate y utilizando
//  las variables estaticas de la clase Vector3
// Autor: Ivan Garcia Subero
// Fecha: 25.03.14
// Licencia: Dominio público
// Dependencias: Debe ser asociado a un objeto con rigidbody
// Por hacer: Nada

using UnityEngine;
using System.Collections;

public class ControladorRigidbody3 : MonoBehaviour {

	public float fuerza = 1;
	public float traccion = 0.5f;

	// Update is called once per frame
	void FixedUpdate ( ) {

		Vector3 vectorFuerza = Input.GetAxis ( "Vertical" ) * Vector3.forward * fuerza;
		rigidbody.AddRelativeForce ( vectorFuerza );
		
		Vector3 vectorTraccion = Input.GetAxis ( "Horizontal" ) * Vector3.up * traccion;
		transform.Rotate ( vectorTraccion );
		
	}
}
