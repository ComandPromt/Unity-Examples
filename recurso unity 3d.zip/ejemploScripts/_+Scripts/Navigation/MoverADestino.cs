using UnityEngine;
using System.Collections;

public class MoverADestino : MonoBehaviour {
	
	public GameObject destino;
	private NavMeshAgent agenteDeNavegacion;
	
	// Use this for initialization
	void Start ( ) {
		agenteDeNavegacion = gameObject.GetComponent<NavMeshAgent> ( );
		agenteDeNavegacion.SetDestination ( destino.transform.position );
	}

}
