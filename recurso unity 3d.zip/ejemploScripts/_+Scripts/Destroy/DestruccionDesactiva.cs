﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestruccionDesactiva : MonoBehaviour {

	public GameObject objeto;
	
	void OnDestroy ( ) {
		objeto.SetActive ( false );
	}

}
