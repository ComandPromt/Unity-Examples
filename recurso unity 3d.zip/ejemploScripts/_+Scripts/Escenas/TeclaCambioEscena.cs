using UnityEngine;
using System.Collections;

public class TeclaCambioEscena : MonoBehaviour {

	public KeyCode tecla;
	public int escena;
	
	// Update is called once per frame
	void Update ( ) {
		
		if ( Input.GetKeyDown ( tecla ) ) {
			Application.LoadLevel ( escena );
		}
		
	}
}
