﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CambioEscenaTemporizado : MonoBehaviour {

	public bool derrota = false;
	private float reloj;
	public float tiempo;
	public int escena;


	
	// Update is called once per frame
	void Update () {

		if (derrota) {
		
			reloj += Time.deltaTime;
		
			if (reloj >= tiempo) {
			
				SceneManager.LoadScene (escena);
			
			}

		}

	}
}
