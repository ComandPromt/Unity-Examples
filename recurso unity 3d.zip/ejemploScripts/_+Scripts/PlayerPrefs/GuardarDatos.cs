﻿using UnityEngine;
using System.Collections;

public class GuardarDatos : MonoBehaviour {

	// Arrastrar a esta variable el texto 3D donde se mostraran los puntos
	public TextMesh texto3d;
	public int puntos = 0;

	// Al empezar se comprueba si se habia creado ya la variable, y si es asi se obtiene su valor
	void Start ( ) {
		if ( PlayerPrefs.HasKey ( "Puntos" ) ) {
			puntos = PlayerPrefs.GetInt ( "Puntos" );
		}
	}

	// Sumamos puntos continuamente y mostramos el valor. Si se pulsa salir guardamos la variable y salimos
	void Update ( ) {

		puntos++;
		texto3d.text = "Puntos: " + puntos;

		if ( Input.GetKey ( KeyCode.Escape ) ) {
			PlayerPrefs.SetInt ( "Puntos" , puntos );
			Application.Quit ( );
		}
	}

}
