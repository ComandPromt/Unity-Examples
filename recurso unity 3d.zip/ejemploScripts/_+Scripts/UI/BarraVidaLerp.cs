﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarraVidaLerp : MonoBehaviour {

	public GameObject barraVerde;
	public GameObject barraAmarilla;

	public float vida;
	public float vidaObjetivo;
	public float vidaMax;

	void Start ( ) {
		Application.targetFrameRate = 60;
		vidaObjetivo = vida;
	}

	// Update is called once per frame
	void Update ( ) {

		// Al recibir daño restamos la vida en una variable auxiliar
		if ( Input.GetKeyDown ( KeyCode.V ) ) {
			vidaObjetivo = vidaObjetivo + Random.Range (-25f,-1f);
		}

		// La barra delantera toma el tamaño ségún la variable auxiliar
		barraVerde.transform.localScale =
			new Vector3 ( vidaObjetivo / vidaMax , 1 , 1 );

		// La vida se acerca suavemente al valor de la variable auxiliar
		vida = Mathf.Lerp ( vida , vidaObjetivo , 0.01f);

		// La barra trasera toma el tamaño según la vida
		barraAmarilla.transform.localScale =
			new Vector3 ( vida / vidaMax , 1 , 1 );

	}

}
