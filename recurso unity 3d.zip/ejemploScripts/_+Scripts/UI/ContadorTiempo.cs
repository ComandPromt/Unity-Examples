﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContadorTiempo : MonoBehaviour {

	public float tiempo = 0f;
	public UnityEngine.UI.Text texto;

	void Update ()
	{
		// Contamos el tiempo
		tiempo += Time.deltaTime;

		// Calculamos los minutos y los segundos
		float segundos = Mathf.FloorToInt(tiempo % 60);
		float minutos = Mathf.FloorToInt(tiempo / 60);

		// Añadimos un cero más si los minutos o los segundos son menores que 10.
		string seg;
		string min;

		if (segundos < 10)
			seg = "0" + segundos;
		else
			seg = segundos.ToString ();

		if (minutos < 10)
			min = "0" + minutos;
		else
			min = minutos.ToString ();

		// Mostramos el tiempo en el texto
		texto.text = (min + " : " + seg);

	}
}
