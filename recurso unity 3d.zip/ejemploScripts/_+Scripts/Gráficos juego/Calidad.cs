﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Calidad : MonoBehaviour {
    [SerializeField]
    public int qualityLevel;

    private void Awake()
    {

        qualityLevel = QualitySettings.GetQualityLevel();
    }

    
    
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyDown("1")) //Calidad basica nivel 1
        {
            QualitySettings.SetQualityLevel(0, true);
        }

        if (Input.GetKeyDown("2")) //Calidad basica nivel 2
        {
            QualitySettings.SetQualityLevel(1, true);
        }

        if (Input.GetKeyDown("3")) //Calidad basica nivel 3
        {
            QualitySettings.SetQualityLevel(2, true);
        }

        if (Input.GetKeyDown("4")) //Buena calidad
        {
            QualitySettings.SetQualityLevel(3, true);
        }

        if (Input.GetKeyDown("5")) //Calidad muy buena
        {
            QualitySettings.SetQualityLevel(4, true);
        }

        if (Input.GetKeyDown("6")) //Calidad fantastica
        {
            QualitySettings.SetQualityLevel(5, true);
        }

    }
}
