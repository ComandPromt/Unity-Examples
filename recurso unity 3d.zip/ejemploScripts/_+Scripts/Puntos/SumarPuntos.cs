﻿using UnityEngine;
using System.Collections;

public class SumarPuntos : MonoBehaviour {

	public int puntosQueSuma = 10;
	public MostrarPuntos script;
	
	// Update is called once per frame
	void OnDestroy ( ) {
		script.puntos = script.puntos + puntosQueSuma;
	}

}
