﻿using UnityEngine;
using System.Collections;

public class MostrarPuntos : MonoBehaviour {

	public int puntos;

	// Use this for initialization
	void OnGUI ( ) {
	
		GUI.Label ( new Rect ( 0 , 0 , 100 , 100 ) , "PUNTOS: " + puntos );

	}

}
