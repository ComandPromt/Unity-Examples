using UnityEngine;
using System.Collections;

public class ControladorRigidbodyJoystick : MonoBehaviour {

	// Objetos de juego con los joysticks, para asignar desde el interfaz
	public GameObject joystickIzquierdo;
	public GameObject joystickDerecho;
	
	// Variables privadas para acceder a los script de cada joystick
	private Joystick joystickIzquierdoScript;
	private Joystick joystickDerechoScript;
	
	// OBtenemos acceso a los scripts
	void Start ( ) {
		joystickIzquierdoScript = joystickIzquierdo.GetComponent<Joystick>( );
		joystickDerechoScript = joystickDerecho.GetComponent<Joystick>( );
	}
	
	// Accede al joystick izquierdo para avanzar y rotar
	void Update ( ) {
		
		rigidbody.AddRelativeForce ( 
			Vector3.forward * joystickIzquierdoScript.position.y ,
			ForceMode.VelocityChange
		);
		
		rigidbody.AddRelativeTorque ( 
			Vector3.up * joystickIzquierdoScript.position.x ,
			ForceMode.VelocityChange
		);
		
		
	}
	
}
