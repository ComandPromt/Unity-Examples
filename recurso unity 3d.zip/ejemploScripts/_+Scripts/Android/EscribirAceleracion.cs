// Script: EscribirAceleracion.cs
// Descripción: Genera un texto en pantalla y muestra el valor que
//  guarda el acelerómetro en un dispositivo Android
// Autor: Iván García Subero, TRINIT Asociación de Informáticos de
//  Zaragoza, http://trinit.es
// Fecha: 26.06.12 12.45
// Licencia: Creative Commons, no comercial con atribución al autor

using UnityEngine;
using System.Collections;

public class EscribirAceleracion : MonoBehaviour {
	
	// Tamaño del texto
	public float anchoBoton = 0.5F;
	public float altoBoton = 0.2F;
	
	// Método de actualización de la GUI
	void OnGUI ( ) {
		GUI.Label ( new Rect ( 0 , 0 ,
			Screen.width*anchoBoton ,
			Screen.height*altoBoton ) ,
			"Aceleracion: " + Input.acceleration );
	}
	
}
