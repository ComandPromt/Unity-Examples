﻿using UnityEngine;
using System.Collections;

public class GirarConJoystick : MonoBehaviour {

	public JoysticTactilAutoposicionable joystickScript;
	public float velocidadGiro = 60f;
	
	// Update is called once per frame
	void Update () {
		transform.Rotate (
			Vector3.right * joystickScript.direccion.y * Time.deltaTime * velocidadGiro );
		transform.Rotate (
			Vector3.up * joystickScript.direccion.x * Time.deltaTime * velocidadGiro);
	}

}
