﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class JoysticTactilAutoposicionable : MonoBehaviour {

	public Vector2 direccion;
	private Vector2 posicionInicial;
	public Rect rectanguloDeAparicion;
	public Image graficoOriginal;
	private Image grafico;
	private Touch toque;
	public bool hayToque;
	public Canvas lienzo;

	void Update ( ) {

		// Si no hay toque detectado en el area, intentamos
		//  obtener el toque detro del area de deteccion
		//if ( !hayToque ) {	
			toque = ObtenerToqueEnArea ( );
		//}

		// Si ya hay un toque fichado
		if ( hayToque ) {

			// Si es primer toque en el area generamos el joystick
			if ( toque.phase == TouchPhase.Began ) {
				// Camera.main.backgroundColor = Color.red;
				ToqueInicial ( );
				return;
			}

			// Si esta moviendose reposicionamos
			if ( toque.phase == TouchPhase.Moved ) {
				Camera.main.backgroundColor = Color.green;
				Arrastre ( );
			}

			// Si termina el toque lo destruimos
			if ( toque.phase == TouchPhase.Ended ) {
				Camera.main.backgroundColor = Color.blue;
				ToqueFinal ( );
			}
		}

	}

	// Gestiona el primer toque, instanciando el joystick
	//  en su posicion
	public void ToqueInicial ( ) {
		grafico = Instantiate ( graficoOriginal ) as Image;
		grafico.transform.parent = lienzo.transform;
		posicionInicial = toque.position;
		grafico.transform.position = toque.position;
	}

	// Gestiona el arrastre, moviendo el joystick a su posicion
	//  y calculando direccion
	public void Arrastre ( ) {
		grafico.transform.position = toque.position;
		direccion = posicionInicial - toque.position;
		direccion.x /= Screen.width;
		direccion.y /= Screen.height;
	}

	// Gestiona el fin de toque, destruyendo el joystick
	public void ToqueFinal ( ) {
		Destroy ( grafico );
		direccion = Vector2.zero;
		hayToque = false;
	}

	// Retorna el toque dentro del area de deteccion, si lo hay
	public Touch ObtenerToqueEnArea ( ) {

		hayToque = false;
		foreach ( Touch toqueActual in Input.touches ) {
			// Vector2 toque
			if ( ( toqueActual.position.x/Screen.width > rectanguloDeAparicion.x ) &&
			    ( toqueActual.position.x/Screen.width < rectanguloDeAparicion.x + rectanguloDeAparicion.width ) &&
			    ( toqueActual.position.y/Screen.height > rectanguloDeAparicion.y ) &&
			    ( toqueActual.position.y/Screen.height < rectanguloDeAparicion.y + rectanguloDeAparicion.height ) ) {

				hayToque = true;
				return toqueActual;
			}
		}

		// Si no habia toque en el area retorna el primero, pero deja la variable
		//  hayToque en false
		return Input.touches [ 0 ];

	}

}
