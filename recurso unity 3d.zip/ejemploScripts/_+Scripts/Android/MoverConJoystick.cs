﻿using UnityEngine;
using System.Collections;

public class MoverConJoystick : MonoBehaviour {

	public JoysticTactilAutoposicionable joystickScript;

	// Update is called once per frame
	void Update () {
		transform.Translate (
			Vector3.forward * joystickScript.direccion.y * Time.deltaTime );
		transform.Translate (
			Vector3.right * joystickScript.direccion.x * Time.deltaTime );
	}

}
