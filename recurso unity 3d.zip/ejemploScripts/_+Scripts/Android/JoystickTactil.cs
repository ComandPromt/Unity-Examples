﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class JoystickTactil : MonoBehaviour {

	public Renderer rendererDebug;

	public Image panel;
	public Image joystick;
	public Rect areaTactil;
	public Vector2 posicion;

	// Update is called once per frame
	public void PosicionarJoystick ( ) {

		Touch toqueActual = new Touch ( );

		// Obtenemos el toque que esta en el area del joystick
		foreach ( Touch toque in Input.touches ) {
			if ( toque.position.x < areaTactil.x + areaTactil.width &&
			    toque.position.x > areaTactil.x &&
			    toque.position.y < areaTactil.y + areaTactil.height &&
			    toque.position.y > areaTactil.y ) {
				toqueActual = toque;
				break;
			}
		}

		// Si no habia dedo en el area retornamos
		if ( toqueActual.position.x <= 1 ) return;

		joystick.rectTransform.position = new Vector3 ( toqueActual.position.x , toqueActual.position.y , 0f );

		posicion = new Vector2 ( joystick.rectTransform.position.x - panel.rectTransform.position.x ,
			joystick.rectTransform.position.y - panel.rectTransform.position.y );

	}

	public void ToqueInicial ( ) {
		rendererDebug.material.color = Color.red;
	}

	public void ToqueArrastre ( ) {
		rendererDebug.material.color = Color.yellow;
	}

	public void ToqueFinal ( ) {
		rendererDebug.material.color = Color.green;
	}

}
