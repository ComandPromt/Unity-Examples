﻿using UnityEngine;
using System.Collections;

public class DesactivarMovimiento : MonoBehaviour {

	public GameObject objetivo;
	public Movimiento scriptMovimiento;

	// Update is called once per frame
	void Update ( ) {
	
		if ( Input.GetKeyDown ( KeyCode.Space ) ) {
			scriptMovimiento = objetivo.GetComponent<Movimiento>( );
			scriptMovimiento.enabled = false;
		}

	}
}
