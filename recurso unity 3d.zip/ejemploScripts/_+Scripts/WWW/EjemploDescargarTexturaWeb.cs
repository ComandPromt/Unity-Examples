﻿// Add this script to a GameObject. The Start() function fetches an
// image from the documentation site.  It is then applied as the
// texture on the GameObject.

using UnityEngine;
using System.Collections;

public class EjemploDescargarTexturaWeb : MonoBehaviour {
    public string urlDirectorio = "http://trinit.es/texturas/";
	public string nombreTextura = "trinit.jpg";

	public int resolucionX = 512, resolucionY = 512;
	public MeshRenderer meshRenderer;

	void Update ( ) {
		if ( !Input.anyKeyDown ) return;
		StartCoroutine ( AplicarTexturaWeb ( ) );
	}

    IEnumerator AplicarTexturaWeb ( ) {
        Texture2D texture2D;
        //texture2D = new Texture2D ( resolucionX , resolucionY , TextureFormat.DXT1 , false );
		texture2D = new Texture2D ( resolucionX , resolucionY );

        using ( WWW www = new WWW ( urlDirectorio + nombreTextura ) ) {
            yield return www;
            www.LoadImageIntoTexture ( texture2D );
            meshRenderer.material.mainTexture = texture2D;
        }
    }
}