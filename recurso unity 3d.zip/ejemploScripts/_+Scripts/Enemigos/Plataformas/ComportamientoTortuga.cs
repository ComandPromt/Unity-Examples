﻿using UnityEngine;
using System.Collections;

public class ComportamientoTortuga : MonoBehaviour {

	public bool izquierda = true;
	public float velocidad = 2f;
	public Vector3 rayoDetector;

	// Update is called once per frame
	void Update ( ) {

		// Si vamos a izquierda desplazamos y ponemos el rayo detector hacia la izquierda
		if ( izquierda ) {
			transform.Translate ( Vector3.left * velocidad * Time.deltaTime );
			rayoDetector = Vector3.down + Vector3.left;
		}
		// Si vamos a derecha desplazamos y ponemos el rayo hacia derecha
		else {
			transform.Translate ( Vector3.right * velocidad * Time.deltaTime );
			rayoDetector = Vector3.down + Vector3.right;
		}

		// Si el rayo ve que no hay nada, cambiamos de direccion para no caernos
		if ( !Physics.Raycast ( transform.position , rayoDetector , 1.5f ) ) {
			izquierda = !izquierda;
		}

	}
}
