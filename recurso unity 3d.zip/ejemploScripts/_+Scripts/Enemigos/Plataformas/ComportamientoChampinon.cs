﻿using UnityEngine;
using System.Collections;

public class ComportamientoChampinon : MonoBehaviour {

	public string tagActivador = "Personaje";
	public float velocidad = 1f;
	
	// Update is called once per frame
	void OnTriggerStay ( Collider infoAcceso ) {

		// Si accede al trigger el objeto con el tag adecuado
		if ( infoAcceso.tag == tagActivador ) {

			// Nos movemos hacia el
			if ( infoAcceso.transform.position.x > transform.position.x ) {
				transform.Translate ( Vector3.right * velocidad * Time.deltaTime );
			}
			else {
				transform.Translate ( Vector3.left * velocidad * Time.deltaTime );
			}

		}
	}
}
