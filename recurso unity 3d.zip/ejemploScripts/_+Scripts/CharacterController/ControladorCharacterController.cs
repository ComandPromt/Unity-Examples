﻿using UnityEngine;
using System.Collections;

public class ControladorCharacterController : MonoBehaviour {

	// Configuracion de velocidades
	public float velocidad = 6.0f;
	public float giro = 90.0f;
	public float salto = 8.0f; 
	public float gravedad = 20.0f;

	public Vector3 movimiento = Vector3.zero;
    public Vector3 movimientoAnterior;
	public CharacterController controladorMovimiento;

	void Update ( ) {

        // Calculamos movimiento segun la entrada de datos
        movimientoAnterior = movimiento;
        movimiento = transform.forward * Input.GetAxis("Vertical") * velocidad;
        movimiento.y = movimientoAnterior.y;

        // Solo respondemos a controles si esta en el suelo
        if (controladorMovimiento.isGrounded){
            // Salto
            if (Input.GetKey(KeyCode.Space)){
                movimiento.y = salto;
            }
        }
        else{
            // Podríamos hacer esto siempre, aunque no esté en el aire
            movimiento.y -= gravedad * Time.deltaTime;
        }

        // Giro
        transform.Rotate ( Input.GetAxis ( "Horizontal" ) * Vector3.up * giro * Time.deltaTime );

		// Movimiento final
		controladorMovimiento.Move ( movimiento * Time.deltaTime );

	}

}
