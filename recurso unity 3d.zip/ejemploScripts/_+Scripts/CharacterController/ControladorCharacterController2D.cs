﻿using UnityEngine;
using System.Collections;

public class ControladorCharacterController2D : MonoBehaviour {

	// Configuracion de velocidades
	public float velocidad = 6.0f;
	public float salto = 8.0f; 
	public float gravedad = 20.0f;

	public Vector3 movimiento = Vector3.zero;
    public Vector3 movimientoAnterior;
	public CharacterController controladorMovimiento;

	void Update ( ) {

        // Solo respondemos a controles si esta en el suelo
        if (controladorMovimiento.isGrounded){
            // Calculamos movimiento segun la entrada de datos
            movimiento = Vector3.right * Input.GetAxis("Horizontal") * velocidad;
            // Salto
            if (Input.GetKey(KeyCode.Space)){
                movimiento.y = salto;
            }
        }
        else{
            movimientoAnterior = movimiento;
            movimiento = Vector3.right * Input.GetAxis("Horizontal") * velocidad/2;
            movimiento.y = movimientoAnterior.y;
            // Podríamos hacer esto siempre, aunque no esté en el aire
            movimiento.y -= gravedad * Time.deltaTime;
        }

		// Movimiento final
		controladorMovimiento.Move ( movimiento * Time.deltaTime );

	}

}
