﻿using UnityEngine;
using System.Collections;

public class CharacterControllerNSaltos : MonoBehaviour {

	// Configuracion de velocidades
	public float velocidad = 6.0f;
	public float giro = 90f;
	public float salto = 8.0f; 
	public float gravedad = 16.0f;

	public int numSaltos = 0;
	public int numSaltosMax = 3;

	public Vector3 movimiento = Vector3.zero;
    private Vector3 movimientoAnterior;
	public CharacterController characterController;

	public bool suelo;
	public float distanciaDeteccion = 1.3f;

	void Update ( ) {

		suelo = Physics.Raycast (transform.position, Vector3.down, distanciaDeteccion);

		// Solo respondemos a controles si esta en el suelo
		if ( suelo ) {

			// Calculamos movimiento segun la entrada de datos
			movimiento = transform.forward * Input.GetAxis("Vertical") * velocidad;

			// Salto
			if (Input.GetKey (KeyCode.Space) ) {
				numSaltos = 1;
				movimiento.y = salto;
                Debug.Log("Primer salto");
			} else {
				numSaltos = 0;
			}
			
		}

		// Si no esta en el suelo aplicamos la gravedad
		else {

            // Calculamos movimiento segun la entrada de datos
            movimientoAnterior = movimiento;
            movimiento = transform.forward * Input.GetAxis("Vertical") * velocidad;
            movimiento.y = movimientoAnterior.y;
            movimiento.y -= gravedad * Time.deltaTime;

			// Segundo salto
			if ( Input.GetKeyDown ( KeyCode.Space ) && ( numSaltos < numSaltosMax ) ) {
				movimiento.y = salto/numSaltos;
				numSaltos++;
			}
		}

		// Giro
		transform.Rotate ( Input.GetAxis ( "Horizontal" ) * Vector3.up * giro * Time.deltaTime );

		// Movimiento final
		characterController.Move ( movimiento * Time.deltaTime );

	}

}
