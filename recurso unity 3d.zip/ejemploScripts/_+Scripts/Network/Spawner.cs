using UnityEngine;
using System.Collections;
 
public class Spawner : MonoBehaviour {
    /*  This file is part of the "Ultimate Unity networking project" by M2H (http://www.M2H.nl)
     *  This project is available on the Unity Store. You are only allowed to use these
     *  resources if you've bought them from the Unity Assets Store.
     */

    public Transform playerPrefab;

	// Ejecutado por el servidor al arrancar
    void OnServerInitialized ( ) {
        SpawnPlayer ( );
    }
	
	// Ejecutado por el cliente al conectarse
    void OnConnectedToServer ( ) {
        SpawnPlayer ( );
    }

    void SpawnPlayer ( ) {
		Network.Instantiate ( playerPrefab , transform.position , transform.rotation , 0 );
    }
	
	// Ejecutado por el servidor en la desconexión de un jugador
    void OnPlayerDisconnected ( NetworkPlayer player ) {
        Debug.Log ( "Clean up after player " + player );
        Network.RemoveRPCs ( player );
        Network.DestroyPlayerObjects ( player );
    }
	
	// Ejecutado por el cliente al desconectarse
    void OnDisconnectedFromServer ( NetworkDisconnection info ) {
        Debug.Log ( "Clean up a bit after server quit" );
        Network.RemoveRPCs ( Network.player );
        Network.DestroyPlayerObjects ( Network.player );

        /* 
        * Note that we only remove our own objects, but we cannot remove the other players 
        * objects since we don't know what they are; we didn't keep track of them. 
        * In a game you would usually reload the level or load the main menu level anyway ;).
        * 
        * To reset the scene we'll just reload it:
        */
        Application.LoadLevel ( Application.loadedLevel );
    }
	
}