using UnityEngine;
using System.Collections;

public class InfoPlayers : MonoBehaviour {
	
	private Rect infoPlayersWindow;
	
	void Update ( ) {
		infoPlayersWindow = new Rect ( Screen.width * 0.5f , 16f , Screen.width * 0.5f , Screen.height * 0.5f );
	}
	
	// Generación de la ventana de información de los jugadors
	void OnGUI ( ) {
		GUI.Window ( 0 , infoPlayersWindow , InfoPlayersWindowContent , "Players info" );
	}
	
	void InfoPlayersWindowContent ( int windowID ) {
		
		GameObject [ ] players = GameObject.FindGameObjectsWithTag ( "Player" );
		
		foreach ( GameObject player in players ) {
			
			Health healthScript = player.GetComponent<Health>( );
			GUILayout.Label ( "Player " + healthScript.networkView.viewID + " health " + healthScript.GetHealth ( ) );
			
		}
		
	}
	
}
