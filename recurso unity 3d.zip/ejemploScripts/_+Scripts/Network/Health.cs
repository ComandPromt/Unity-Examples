using UnityEngine;
using System.Collections;

public class Health : MonoBehaviour {

	// Health of the Warlord
	private float health = 100.0f;
	
	public void ModifyHealth ( float healthModifier ) {
		health += healthModifier;
	}
	
	public float GetHealth ( ) {
		return health;
	}
	
}
