using UnityEngine;
using System.Collections;

public class Control : MonoBehaviour {
	
	public ScaledRect quitButton;
	
	void Start ( ) {
		Screen.sleepTimeout = 0;
		quitButton = new ScaledRect ( 80 , 80 , 20 , 20 );
	}
	
	// Update is called once per frame
	void OnGUI ( ) {
	
		if ( GUI.Button ( quitButton , "EXIT" ) ) {
			Application.Quit ( );
		}
		
	}
}
