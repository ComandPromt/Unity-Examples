using UnityEngine;
using System.Collections;
 
public class Controller : MonoBehaviour{
    
	/*  This file is part of the "Ultimate Unity networking project" by M2H (http://www.M2H.nl)
     *  This project is available on the Unity Store. You are only allowed to use these
     *  resources if you've bought them from the Unity Assets Store.
     */
	
	private float fuerza = 0.02f;
	private float fuerzaDisparo = 500.0f;
	public GameObject shoot;
	private GameObject shootClon;
	public Joystick joystick;
	
	// Eliminamos el control de movimiento de los clientes remotos
    void Awake ( ) {
		if ( !networkView.isMine ) {
            Destroy ( this );
        }
		joystick = GameObject.Find ( "Joystick" ).GetComponent<Joystick>( );
    }
	
	// Controles del cliente local
    void FixedUpdate ( ) {
		
		// Movimiento
		Vector3 moveDirection;
		#if UNITY_ANDROID
		moveDirection = new Vector3 ( joystick.position.x , 0 , joystick.position.y );
		#endif
		#if UNITY_STANDALONE_WIN 
		moveDirection = new Vector3 ( Input.GetAxis("Horizontal") , 0 , Input.GetAxis ( "Vertical" ) );
		#endif
		#if UNITY_EDITOR 
		moveDirection = new Vector3 ( Input.GetAxis("Horizontal") , 0 , Input.GetAxis ( "Vertical" ) );
		#endif
		rigidbody.AddRelativeForce ( fuerza * moveDirection , ForceMode.VelocityChange );
		
		// Disparo
		bool disparar = ( Input.touchCount > 0 ) && ( Input.touches [ 0 ].phase == TouchPhase.Began );
		if ( Input.GetMouseButtonDown ( 0 ) || disparar ) {
			shootClon = Network.Instantiate ( shoot , transform.position + 1.5f*transform.forward , transform.rotation , 0 )
				as GameObject;
			shootClon.rigidbody.AddRelativeForce ( Vector3.forward * fuerzaDisparo , ForceMode.Impulse );
		}
		
    }
	
}