﻿using UnityEngine;
using System.Collections;

public class Desviar : MonoBehaviour {

	public Vector3 direccion;
	public float desviacion = 10f;
	
	void Update ( ) {
		
		// Alineamos el objeto con la direccion
		transform.forward = direccion;
		
		// Al pulsar una tecla calculamos una nueva direccion desviada
		if ( Input.anyKeyDown ) {
			direccion = Desviar ( direccion , desviacion );
		}
		
	}
	
	// Dado un vector y unos grados de desviacion, este metodo
	//  nos devuelve el mismo vector desviado como maximo esos grados
	Vector3 Desviar ( Vector3 vector , float cuanto ) {
		
		// Calculamos la nueva direccion (Sin magnitud, con longitud aprox.2)
		Vector3 direccion =
			vector.normalized +
				Random.onUnitSphere * Mathf.Sin ( cuanto * Mathf.Deg2Rad );
		
		// Devolvemos la nueva direccion con la magnitud del vector inicial
		return direccion.normalized * vector.magnitude;
	}

}
