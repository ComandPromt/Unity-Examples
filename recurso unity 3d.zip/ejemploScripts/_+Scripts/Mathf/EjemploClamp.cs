﻿using UnityEngine;
using System.Collections;

public class EjemploClamp : MonoBehaviour {

	public int vida = 80;
	
	// Update is called once per frame
	void Update ( ) {

		vida += Random.Range ( -10 , 11 );

		vida = Mathf.Clamp ( vida , 0 , 100 );

	}
}
