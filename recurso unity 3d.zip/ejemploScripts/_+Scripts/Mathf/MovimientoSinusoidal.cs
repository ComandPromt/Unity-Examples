﻿using UnityEngine;
using System.Collections;

public class MovimientoSinusoidal : MonoBehaviour {

	public float tiempo;
	
	// Update is called once per frame
	void Update ( ) {

		tiempo += Time.deltaTime;

		transform.position = new Vector3 ( 0 , Mathf.Cos ( tiempo * Mathf.Deg2Rad ) , 0 );

	}

}
