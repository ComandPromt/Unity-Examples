// Script: InstanciaConColision.cs
// Descripción: Instancia un objeto dado desde el interfaz cuando
//  se detecta colisión y destruye el objeto generador.
//  El objeto se clona en la misma posición y rotación que el objeto
//  que lo instancia
// Autor: Iván García Subero, TRINIT Asociación de Informáticos de
//  Zaragoza, http://trinit.es
// Fecha: 09.03.12 16.1
// Licencia: Creative Commons, no comercial con atribución al autor

using UnityEngine;
using System.Collections;

public class InstanciaConColision : MonoBehaviour {
	
	// Zona de variables
	public GameObject objeto;
	
	// Función de actualización
	void OnCollisionEnter ( ) {
		Instantiate ( objeto , transform.position , transform.rotation );

		// Al final autodestruye el objeto que lleva el script, quitar esta linea para que no lo haga
		Destroy ( gameObject );
	}
}
