﻿using UnityEngine;
using System.Collections;

public class SpawnerComplejo : MonoBehaviour {

	public GameObject objeto;
	private GameObject objetoClon;

	public float contador = 0f;
	public float contadorMax = 1f;
	public float radio = 10f;
	
	// Update is called once per frame
	void Update ( ) {

		// Contamos tiempo para el siguiente respawn
		contador = contador + 1f * Time.deltaTime;

		// Si no es tiempo de clonar retornamos (Dejamos de ejecutar)
		if ( contador < contadorMax ) return;

		// Generamos una posicion aleatoria en un disco de determinado radio
		Vector3 posicion = Random.insideUnitSphere * radio;
		posicion.y = 0f;

		// Clonamos
		objetoClon = Instantiate ( objeto ,
			transform.position + posicion , transform.rotation ) as GameObject;

		// Modificamos el color del clon (Por modificar algo)
		objetoClon.renderer.material.color = 
			new Color ( Random.value , Random.value , Random.value );

		contador = 0f;

	}

}
