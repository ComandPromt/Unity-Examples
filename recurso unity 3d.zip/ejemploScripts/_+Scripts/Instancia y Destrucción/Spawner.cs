﻿using UnityEngine;
using System.Collections;

public class Spawner : MonoBehaviour {

	public GameObject objeto;
	
	// Update is called once per frame
	void Update ( ) {
		Instantiate ( objeto , transform.position , transform.rotation );
	}

}
