// Script: InstanciarAlDestruir.cs
// Descripción: Se encarga de instanciar un objeto dado como parámetro en la misma posición que el
//  objeto que lleva este script cuando éste es destruido
// Autor: Iván García Subero, http://trinit.es
// Dependencias: El objeto a instanciar debe ser asignado desde el interfaz

using UnityEngine;
using System.Collections;

public class InstanciarAlDestruir : MonoBehaviour {
	
	// Arrastrar aquí el objeto que queremos que sea instanciado
	public GameObject objeto;
	
	// Este método se invoca automáticamente cuando el objeto que lleva este script es destruido
	void OnDestroy ( ) {
	
		// Se instancia el objeto pasado como parámetro en la misma posición y rotación
		Instantiate ( objeto ,  transform.position , transform.rotation );
		
	}
	
}
