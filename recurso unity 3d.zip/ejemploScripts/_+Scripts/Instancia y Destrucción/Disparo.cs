﻿using UnityEngine;
using System.Collections;

public class Disparo : MonoBehaviour {

	public GameObject prefab;
	private GameObject prefabClon;
	private Rigidbody rigidbodyClon;
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown (0)) {
			prefabClon = Instantiate (prefab, transform.position, transform.rotation) as GameObject;
			rigidbodyClon = prefabClon.GetComponent<Rigidbody> ();
			rigidbodyClon.AddRelativeForce ( Vector3.forward * 300 , ForceMode.Impulse);
		}

	}
}
