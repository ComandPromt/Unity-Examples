﻿using UnityEngine;
using System.Collections;

public class Destrucciones : MonoBehaviour {

	public GameObject otro;

	// Update is called once per frame
	void Update ( ) {

		// Autodestruccion del objeto entero
		if ( Input.GetKey ( KeyCode.Alpha1 ) ) {
			Destroy ( gameObject );
		}
		// Autodestruccion solo de este script
		if ( Input.GetKey ( KeyCode.Alpha2 ) ) {
			Destroy ( this );
		}
		// Destruccion del objeto que tenemos en la variable
		if ( Input.GetKey ( KeyCode.Alpha3 ) ) {
			Destroy ( otro );
		}
		// Destruccion solo del rigidbody del objeto que tenemos en la variable
		if ( Input.GetKey ( KeyCode.Alpha4 ) ) {
			if ( otro != null ) {
				if ( otro.rigidbody != null ) {
					Destroy ( otro.rigidbody );
				}
			}
		}
		// Autodestruccion temporizada
		if ( Input.GetKey ( KeyCode.Alpha5 ) ) {
			Destroy ( gameObject , 3f );
		}
		// Destruccion temporizada del clon
		if ( Input.GetKey ( KeyCode.Alpha6 ) ) {
			Destroy ( otro , 3f );
			Destroy ( this );
		}
	
	}
}
