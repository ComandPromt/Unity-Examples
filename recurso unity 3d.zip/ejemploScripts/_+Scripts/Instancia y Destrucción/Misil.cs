﻿// Comportamiento de un misil, se le pasa un prefab de explosión y se encarga
//  de clonarlo y destruirse cuando impacta con algo
using UnityEngine;

public class Misil : MonoBehaviour {

	public GameObject prefab;
	public Rigidbody rigidbody;

	void Start ( ) {
		rigidbody = GetComponent<Rigidbody> ();
	}

	void Update ( ) {
		// Aerodinámica básica
		transform.forward = rigidbody.velocity;
	}

	// Update is called once per frame
	void OnCollisionEnter () {
		Instantiate (prefab, transform.position, Quaternion.identity);
		Destroy (gameObject);
	}
}
