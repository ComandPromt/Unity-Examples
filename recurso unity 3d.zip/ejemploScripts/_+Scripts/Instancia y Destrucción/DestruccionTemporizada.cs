﻿using UnityEngine;
using System.Collections;

public class DestruccionTemporizada : MonoBehaviour {

	public float tiempo;
	
	// Update is called once per frame
	void Start ( ) {
		Destroy ( gameObject , tiempo );
		Destroy ( this );
	}
}
