// Script: InstanciaConTecla.cs
// Descripción: Instancia un objeto dado desde el interfaz cuando
//  se pulsa la tecla, que también puede asignarse desde el interfaz.
//  El objeto se clona en la misma posición y rotación que el objeto
//  que lo instancia
// Autor: Iván García Subero, TRINIT Asociación de Informáticos de
//  Zaragoza, http://trinit.es
// Fecha: 09.03.12 16.13
// Licencia: Creative Commons, no comercial con atribución al autor

using UnityEngine;
using System.Collections;

public class InstanciaConTecla : MonoBehaviour {
	
	// Zona de variables
	public GameObject objeto;
	public KeyCode tecla;
	
	// Función de actualización
	void Update ( ) {
		if ( Input.GetKeyDown ( tecla ) ) {
			Instantiate ( objeto ,
				transform.position , 
				transform.rotation );
		}
	}

}
