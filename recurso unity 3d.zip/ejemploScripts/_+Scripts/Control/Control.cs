﻿// Control.cs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Control : MonoBehaviour {

	public static Control main;		// Cualquier otro objeto podrá acceder aquí con Control.main
	public static bool pausa = false;

	public GameObject personaje;	// El control siempre tendrá acceso al personaje

	// Variables globales de uso general
	public static double G = -6.674f * Mathf.Pow ( 10 , -14 );
	public static float g = -9.81f;

	// Use this for initialization
	void Start () {
		main = this;
	}

	public void Pausar ( ) {
		pausa = !pausa;
		PausarObjetosProblematicos (pausa);
		if ( pausa ) {
			Time.timeScale = 0f;
		} else {
			Time.timeScale = 1f;	
		}
	}

	public void CambiarNivel ( int nivel ) {
		SceneManager.LoadScene ( nivel );
	}

	public void PausarObjetosProblematicos ( bool estado ) {
		ColorCamara scriptA = Camera.main.gameObject.GetComponent<ColorCamara> ();
		if (scriptA) {
			scriptA.enabled = !estado;
		}
	}

}
