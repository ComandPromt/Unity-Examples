﻿using UnityEngine;
using System.Collections;

public class ControlMuerte2 : MonoBehaviour {

	public int escenaDestino;
	
	// Update is called once per frame
	void OnDestroy ( ) {
		Application.LoadLevel ( escenaDestino );
	}

}
