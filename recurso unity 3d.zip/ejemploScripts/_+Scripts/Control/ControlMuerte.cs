﻿using UnityEngine;
using System.Collections;

public class ControlMuerte : MonoBehaviour {

	public GameObject personaje;
	public int escenaDestino;
	
	// Update is called once per frame
	void Update ( ) {
	
		if (!personaje) {
			Application.LoadLevel ( escenaDestino );
		}

	}
}
