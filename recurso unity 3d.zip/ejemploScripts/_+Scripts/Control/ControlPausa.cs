﻿using UnityEngine;
using System.Collections;

public class ControlPausa : MonoBehaviour {

	// El contenido de Update se ejecuta en todos los frames
	void Update ( ) {
	
		// Condicion: Si se pulsa P
		if ( Input.GetKeyDown ( KeyCode.P ) ) {

			// Si el tiempo estaba a 0 lo devolvemos a 1 (no pausa)
			if ( Time.timeScale == 0f ) {
				Time.timeScale = 1f;
			}
			// En cambio si estaba a 1 lo devolvemos a 0 (pausa)
			else if ( Time.timeScale == 1f ) {
				Time.timeScale = 0f;
			}

		}

	}

}
