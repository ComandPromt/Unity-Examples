﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DesactivarSiNoHayComponente : MonoBehaviour {

	public Component componente;
	public GameObject objeto;

	// Update is called once per frame
	void Update () {
		if ( componente != null ) return;
		objeto.SetActive ( false );
	}
}
