﻿using UnityEngine;
using System.Collections;

public class InterfazAdaptable : MonoBehaviour {

	public float originalWidth = 1024;
	public float originalHeight = 768;

	public GUISkin skin;
	public Rect rectangulo;

	void OnGUI ( ) {

		// Configuracion de la matriz de GUI para escalado dinamico con los cambios de resolucion de pantalla
		Vector2 ratio = new Vector2(Screen.width/originalWidth , Screen.height/originalHeight );
		Matrix4x4 guiMatrix = Matrix4x4.identity;
		guiMatrix.SetTRS(new Vector3(1, 1, 1), Quaternion.identity, new Vector3(ratio.x, ratio.y, 1));
		GUI.matrix = guiMatrix;

		// Dibujado de la GUI
		GUI.skin = skin;
		GUI.Button ( rectangulo , "MUHAHAHA" );

		// Reseteo de la matriz de GUI antes de la siguiente ejecucion
		GUI.matrix = Matrix4x4.identity;

	}
}
