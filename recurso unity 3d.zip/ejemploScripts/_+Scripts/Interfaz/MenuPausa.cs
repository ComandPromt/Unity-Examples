﻿// Script: MenuPausa.cs
// Descripción: Menu de Pausa para salir del juego, mientras el tiempo de juego se para.
// Autor: Victor Martinez con ayuda de Tomas Pimpinela.
// Fecha: 25.3.2014  17:24 
// Licencia: Dominio Publico, pero se aceptan donaciones. 
// Dependencias: Escenas deben ser añadidas desde la pestaña --> File/Buildsettins
// Por hacer: Nada

using UnityEngine;
using System.Collections;

public class MenuPausa : MonoBehaviour {

	public ScaledRect rectangulo = new ScaledRect ( 25f, 34.375f , 50f , 31.25f );
	public ScaledRect rectanguloSi = new ScaledRect ( 5f , 11f , 18f , 11.25f); 
	public ScaledRect rectanguloNo = new ScaledRect ( 27f , 11f , 18f , 11.25f);
	public bool activado;
	
	void Start(){
		activado=false;
	}

	// Actualiza la variable activado para sacar el menu o no
	void Update ( ) {
		if (Input.GetKeyUp (KeyCode.Escape)) {
			activado = !activado;
		}
	}
	
	// Update is called once per frame
	void OnGUI () {
		
		
		// Muestra la ventana de menu cuando la variable activado lo indice
		if( activado == true ){
			Time.timeScale = 0;
			GUI.Window ( 0 , rectangulo , ContenidoVentana , "¿Desea salir del juego ?" );
		}
		else {
			Time.timeScale = 1;
		}
		
		
		
	}
	
	
	void ContenidoVentana ( int windowID ) {
		// El boton NO cierra el menu
		if (GUI.Button(rectanguloNo, "No")){
			activado=false;
			
		}
		// El boton SI sale de la aplicacion si estaba en la escena 0, y si no va a la escena 0
		if (GUI.Button(rectanguloSi, "Si")) {
			if ( Application.loadedLevel == 0 ) {
				Application.Quit ();
			}
			
			else  {
				Application.LoadLevel (0);
			}
			
		}
		
		
		
	}
	
}
