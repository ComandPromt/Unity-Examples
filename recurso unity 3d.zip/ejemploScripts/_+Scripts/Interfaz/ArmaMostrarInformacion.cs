﻿using UnityEngine;
using System.Collections;

public class ArmaMostrarInformacion : MonoBehaviour {

	public string nombreArma;
	public GameObject tipoMunicion;
	public int cantidadMaximaCargador;
	public int cantidadCargador;
	public int cantidadMaximaMunicion;
	public int cantidadMunicion;


	void MostrarInformacion ( ){
	
		print ("Nombre arma: " + nombreArma);
		print ("Tipo municion: " + tipoMunicion);
		print ("Cantidad maxima cargador: " + cantidadMaximaCargador);
		print ("Cantidad cargador: " + cantidadCargador);
		print ("Cantidad maxima municion: " + cantidadMaximaMunicion);
		print ("Cantidad municion: " + cantidadMunicion);

	}

	void OnGUI () {
		//Caja exterior
		GUI.Box(new Rect (0,0,200,140), "Infomacion Arma");
		
		//Botones Interior
		GUI.Button(new Rect (0,20,200,20), "Nombre arma: " + nombreArma); 
		GUI.Button(new Rect (0,40,200,20), "Tipo Municion: " + tipoMunicion ); 
		GUI.Button(new Rect (0,60,200,20), "Cantidad maxima cargador: " + cantidadMaximaCargador);
		GUI.Button(new Rect (0,80,200,20),"Cantidad cargador: " + cantidadCargador);
		GUI.Button(new Rect (0,100,200,20), "Cantidad maxima municion: " + cantidadMaximaMunicion );
		GUI.Button(new Rect (0,120,200,20), "Cantidad municion: " + cantidadMunicion );

		}
}

