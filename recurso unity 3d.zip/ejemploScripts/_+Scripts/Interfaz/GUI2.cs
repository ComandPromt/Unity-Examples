﻿using UnityEngine;
using System.Collections;

public class GUI2 : GUI {

	public static float baseWidth = 1024;
	public static float baseHeight = 768;

	// Configuracion de la matriz de GUI para escalado dinamico con los cambios de resolucion de pantalla.
	//  Invocar este metodo antes de dibujar la GUI y basar sus dimensiones en las variables baseWidth y baseHeight
	public static void ScaleGUI () {
		Vector2 ratio = new Vector2 ( Screen.width/baseWidth , Screen.height/baseHeight );
		Matrix4x4 guiMatrix = Matrix4x4.identity;
		guiMatrix.SetTRS ( Vector3.zero , Quaternion.identity , new Vector3 ( ratio.x , ratio.y , 1 ) );
		GUI.matrix = guiMatrix;
	}
	
	// Reseteo de la matriz de GUI antes de la siguiente ejecucion. Invocar este metodo despues de dibujar la GUI
	public static void ResetGUI () {
		GUI.matrix = Matrix4x4.identity;
	}

}
