﻿using UnityEngine;
using System.Collections;

public class MenuGUI : MonoBehaviour {


	void OnGUI () {
		GUI.Box    (new Rect(350,100,200,250), "Menu Principal");
		GUI.Button (new Rect(375,150,150,20), "Partida Nueva");
		GUI.Button (new Rect(375,200,150,20), "Continuar Partida" );
		GUI.Button (new Rect(375,250,150,20), "Opciones" );
		GUI.Button (new Rect(375,300,150,20), "Salir");

	}
}
