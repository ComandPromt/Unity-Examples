﻿using UnityEngine;
using System.Collections;

public class GUITest : MonoBehaviour {


	public string nombre = "Your User name" ;
	public float volumen;

	void OnGUI () {
		GUI.Button(new Rect(400f,290f,100f,20f),"Menu principal");
		GUI.Box  (new Rect(250f,50f,400f,285.9f) , "Opciones");
		GUI.Label(new Rect(266.02f,82.9f,70f,20f), "User Name:");
		GUI.Label(new Rect(422.2f,209.6f,63.3f,37.5f), "Volumen:" );
		GUI.Label(new Rect(425f,128.35f,70f,20f), "Graficos:");
		GUI.Label(new Rect(562.33f,243f,30f,20f), "Max.");
		GUI.Label(new Rect(328.8f,243f,203f,20f), "Min.");
		GUI.Toggle(new Rect(300f,160f,150f,20f),false," Graficos Altos " );
		GUI.Toggle(new Rect (480f,160f,150f,20f),true, " Graficos Bajos ");
		nombre = GUI.TextField(new Rect(344.36f,82.9f,200f,20f), nombre,25);
		volumen = GUI.HorizontalSlider (new Rect(356.1f,249.44f,200f,0f) ,volumen,0.0f,10.0f);


	
	}
}
