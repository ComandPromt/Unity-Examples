// Script: ScaledRect.cs
// Descripci�n: Clase para generar objetos de GUI que se adaptan a la pantalla
// Autor: Guillermo Calvo
// Fecha: 20.11.12 12.00
// Licencia: Dominio p�blico
// Dependencias: Ninguna
// Por hacer: Nada

using UnityEngine;

[System.Serializable]
public class ScaledRect{

	public float left;
	public float top;
	public float width;
	public float height;
	
	/* constructor */
	public ScaledRect(float left, float top, float width, float height){

		this.left	= left;
		this.top	= top;
		this.width	= width;
		this.height	= height;
	}
	
	/* returns an absolute rectangle by using given position/size as container */
	public Rect RelativeRect(float offsetLeft, float offsetTop, float totalWidth, float totalHeight){

		float x = offsetLeft + this.left * totalWidth / 100;
		float y = offsetTop + this.top * totalHeight / 100;
		float w = this.width * totalWidth / 100;
		float z = this.height * totalHeight / 100;

		return( new Rect(x, y, w, z) );
	}
	
	/* returns an absolute rectangle by using another rectangle as container */
	public Rect RelativeRect(Rect relativeRect){

		return( this.RelativeRect(relativeRect.x, relativeRect.y, relativeRect.width, relativeRect.height) );
	}
	
	/* converts this scaled rectangle into an absolute rectangle by using the screen as container */
	public static implicit operator Rect(ScaledRect scaledRect){

		return( scaledRect.RelativeRect(0, 0, Screen.width, Screen.height) );
	}

}
