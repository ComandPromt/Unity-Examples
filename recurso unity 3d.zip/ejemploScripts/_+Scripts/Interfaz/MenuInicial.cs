using UnityEngine;
using System.Collections;

public class MenuInicial : MonoBehaviour {

	// Arrastrar aqui la GUI Skin con la que queremos dibujar
	public GUISkin skin;

	// Determinar aqui los rectangulos en pixeles para cada boton
	//  podrian reemplazarse por ScaledRect!
	public Rect botonJugar = new Rect ( 200 , 200 , 200 , 100 );
	public Rect botonSalir = new Rect ( 200, 400 , 200 , 100 );
	
	// Update is called once per frame
	void OnGUI ( ) {
	
		// Indicamos que vamos a usar la skin para dibujar
		GUI.skin = skin;

		// Pintamos los botones y comprobamos si son pulsados para hacer el cambio de
		//  escena o salir del juego
		if ( GUI.Button ( botonJugar , "PLAY" ) ) {
			Application.LoadLevel ( 1 );
		}
		else if ( GUI.Button ( botonSalir , "QUIT" ) ) {
			Application.Quit ( );
		}
		
	}
}
