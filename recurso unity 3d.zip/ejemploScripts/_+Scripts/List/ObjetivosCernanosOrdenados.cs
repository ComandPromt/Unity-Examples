﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjetivosCernanosOrdenados : MonoBehaviour
{
    public float distancia;

    [System.Serializable]
    public class DiferenciaDePosicion
    {
        public Collider objetivo;
        public Vector3 diferencia;
    }

    public List<DiferenciaDePosicion> diferenciaObjetivos;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown (KeyCode.O) ) {
            BuscarObjetivosCercanos();
        }
    }

    void BuscarObjetivosCercanos()
    {
        Collider[] objetivos = Physics.OverlapSphere(transform.position, distancia);
        diferenciaObjetivos.Clear();
        foreach (Collider objetivo in objetivos)
        {
            DiferenciaDePosicion diferenciaDePosicion = new DiferenciaDePosicion();
            diferenciaDePosicion.objetivo = objetivo;
            diferenciaDePosicion.diferencia = objetivo.transform.position - transform.position;
            diferenciaObjetivos.Add(diferenciaDePosicion);
        }

        diferenciaObjetivos.Sort((IComparer<DiferenciaDePosicion>)new CompararDistancia());

        for (int i = 0; i < diferenciaObjetivos.Count; i++)
        {
            diferenciaObjetivos[i].objetivo.GetComponent<MeshRenderer>().material.color =
                new Color(diferenciaObjetivos[i].diferencia.magnitude / distancia,
                0,
                0);
        }

    }

    private class CompararDistancia : IComparer<DiferenciaDePosicion>
    {
        int IComparer<DiferenciaDePosicion>.Compare(DiferenciaDePosicion a, DiferenciaDePosicion b)
        {
            int diferenciaX = (int)a.diferencia.magnitude*100;
            int diferenciaY = (int)b.diferencia.magnitude*100;
            return diferenciaX.CompareTo(diferenciaY);
        }
    }
}