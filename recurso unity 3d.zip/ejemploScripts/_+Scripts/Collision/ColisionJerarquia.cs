﻿using UnityEngine;
using System.Collections;

public class ColisionJerarquia : MonoBehaviour {
	
	// Detectamos colision
	void OnCollisionEnter ( Collision infoColision ) {

		if ( infoColision.gameObject.name != "Lanza" ) {

			// Escribimos el nombre del objeto que hemos tocado
			print ( infoColision.gameObject.name );

			// Nos jerarquizamos con el objeto tocado
			transform.parent = infoColision.transform;

			// Quitamos el rigidbody para no liarla porque solo
			//  tiene que haber un rigidbody en el padre
			Destroy ( rigidbody );
			Destroy ( this );

		}

	}

}
