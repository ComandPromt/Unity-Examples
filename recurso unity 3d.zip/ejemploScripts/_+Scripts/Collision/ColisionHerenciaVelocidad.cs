﻿using UnityEngine;
using System.Collections;

public class ColisionHerenciaVelocidad : MonoBehaviour {

	public float porcentajeHerencia = 0.75f;
	
	// Update is called once per frame
	void OnCollisionStay ( Collision infoColision ) {
		print ("lol");
		rigidbody.velocity += infoColision.rigidbody.velocity * porcentajeHerencia;
	}
}
