﻿using UnityEngine;
using System.Collections;

public class EventoColision : MonoBehaviour {

	void OnCollisionEnter ( Collision infoColision ) {
		print ( "Impacto a velocidad " +
			infoColision.relativeVelocity.magnitude );
	}

}
