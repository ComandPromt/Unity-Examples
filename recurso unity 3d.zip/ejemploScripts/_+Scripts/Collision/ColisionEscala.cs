﻿using UnityEngine;
using System.Collections;

public class ColisionEscala : MonoBehaviour {

	// Si hay evento de colision
	void OnCollisionEnter ( Collision infoColision ) {

		// Reducimos la escala uniformemente en funcion de la
		//  velocidad de colision (Dividida por 100 para que
		//  vaya mas lento)
		transform.localScale -= Vector3.one *
			( infoColision.relativeVelocity.magnitude / 100f );

	}

	// Comprobamos si la escala baja de 0 para destruir el objeto
	void Update ( ) {
		if ( transform.localScale.magnitude < 0 ) {
			Destroy ( gameObject );
		}
	}

}
