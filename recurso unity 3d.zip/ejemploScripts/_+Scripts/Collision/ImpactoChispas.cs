﻿using UnityEngine;
using System.Collections;

public class ImpactoChispas : MonoBehaviour {

	// Elemento que instanciaremos en cada choque
	public GameObject chispas;
	private GameObject	chispasClon;

	// Update is called once per frame
	void OnCollisionEnter ( Collision infoColision ) {

		// Instanciamos en el primer punto de impacto
		chispasClon = Instantiate ( chispas , 
			infoColision.contacts [ 0 ].point ,
		    transform.rotation ) as GameObject;

		// Alineamos con la normal de impacto
		chispasClon.transform.up =
			infoColision.contacts [0].normal;

	}
}
