﻿using UnityEngine;
using System.Collections;

public class ColisionDestruir : MonoBehaviour {

	public string tagComprobar = "Enemigo";
	
	void OnCollisionEnter ( Collision infoColision ) {
		if ( infoColision.gameObject.tag == tagComprobar ) {
			Destroy ( gameObject );
		}
	}

}
