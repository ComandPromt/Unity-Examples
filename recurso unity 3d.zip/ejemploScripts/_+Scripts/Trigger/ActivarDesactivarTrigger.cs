﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActivarDesactivarTrigger : MonoBehaviour {

	public GameObject objeto;
	public string tag;
	
	void OnTriggerEnter(Collider info) {

		if (tag == info.tag) {
			objeto.SetActive (true);
		}

	}

	void OnTriggerExit(Collider info) {

		if (tag == info.tag) {
			objeto.SetActive (false);
		}

	}

}
