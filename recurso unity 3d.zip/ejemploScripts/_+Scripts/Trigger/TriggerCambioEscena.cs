﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TriggerCambioEscena : MonoBehaviour {
	
	public string tagComprobar = "Enemigo";
	public int escenaDestino = 1;
	
	void OnTriggerEnter ( Collider infoTrigger ) {
		if ( infoTrigger.gameObject.tag == tagComprobar ) {
			SceneManager.LoadScene ( escenaDestino );
		}
	}
	
}