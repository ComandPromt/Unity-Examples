﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Activa el objeto delantero si al entrar el personaje en el trigger entra desde atrás,
//  y activa el objeto trasero si entra desde adelante
public class TriggerCambioCamara : MonoBehaviour {

	public GameObject objetoDelantero;
	public GameObject objetoTrasero;
	public string tagComprobar = "Player";
	public Vector3 diferencia;

	void OnTriggerEnter ( Collider infoAcceso ) {

		if ( infoAcceso.tag != tagComprobar ) return;

		diferencia = infoAcceso.transform.position - transform.position;
		diferencia = transform.InverseTransformDirection ( diferencia );

		objetoDelantero.SetActive ( diferencia.z > 0 );
		objetoTrasero.SetActive ( diferencia.z < 0 );

	}

}
