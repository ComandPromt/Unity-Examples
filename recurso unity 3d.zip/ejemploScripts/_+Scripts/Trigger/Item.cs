﻿using UnityEngine;
using System.Collections;

public class Item : MonoBehaviour {

	public string tagPersonaje = "Player";

	// Update is called once per frame
	void OnTriggerEnter ( Collider infoAccceso ) {
		if ( infoAccceso.tag == tagPersonaje ) {
			Destroy ( gameObject );
		}
	}

}
