﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TriggerPausaActivaAnimator : MonoBehaviour {
	
	public Animator animator;
	public string nombreParametro;
	public string tagComprobar = "Player";
	public GameObject objetoActivar;	// Se pueden meter más GameObject en líneas siguientes...
	
	void OnTriggerEnter ( Collider infoTrigger ) {
		if ( infoTrigger.tag != tagComprobar ) return;
		if ( animator.GetBool ( nombreParametro ) ) return;
		Time.timeScale = 0f;
		objetoActivar.SetActive ( true );
	}
	
}