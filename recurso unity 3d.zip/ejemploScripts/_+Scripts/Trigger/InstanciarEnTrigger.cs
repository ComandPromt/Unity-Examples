﻿using UnityEngine;
using System.Collections;

public class InstanciarEnTrigger : MonoBehaviour {

	public GameObject objetoParaInstanciar;
	public string tagComprobar = "Player";
	public float tiempoSpawn;
	public float tiempoSpawnMax;
	public float radioAparicion = 5f;

	void OnTriggerStay ( Collider infoAcceso ) {
		
		// Si el objeto que permanece en trigger NO tiene el tag que buscamos, salimos
		if ( infoAcceso.tag != tagComprobar ) return;

		// Contamos tiempo, si no ha llegado el momento, salimos
		tiempoSpawn -= Time.deltaTime;
		if ( tiempoSpawn > 0f ) return;

		// Calculamos la posicion de aparicion aleatoria en un radio
		Vector3 posicionAparicion = transform.posicion +
			Vector3.right * Random.Range ( -radioAparicion ,  radioAparicion ) +
			Vector3.forward * Random.Range ( -radioAparicion , radioAparicion );

		// Si es momento de clonar lo hacemos 
		Instantiate ( objetoParaInstanciar ,
			posicionAparicion ,
			transform.rotation );

		// Finalmente reseteamos el contador para que sigan saliendo más
		tiempoSpawn = tiempoSpawnMax;

	}


}
