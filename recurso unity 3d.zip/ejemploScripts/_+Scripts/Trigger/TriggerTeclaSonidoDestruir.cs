﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerTeclaSonidoDestruir : MonoBehaviour {

	public KeyCode tecla = KeyCode.E;
	public AudioSource audioSource;
	public string tagComprobar = "Player";
	public GameObject objetoDestruir;		// Objeto y componente a destruir, si es que los hay
	public Component componenteDestruir;
	
	void Start ( ) {
		audioSource = GetComponent<AudioSource>( );
	}

	void OnTriggerStay ( Collider infoAcceso ) {
		if ( infoAcceso.tag != tagComprobar ) return;
		if ( Input.GetKeyDown ( tecla ) == false ) return;
		audioSource.PlayOneShot ( audioSource.clip );
		Destroy ( objetoDestruir );
		Destroy ( componenteDestruir );
	}

}
