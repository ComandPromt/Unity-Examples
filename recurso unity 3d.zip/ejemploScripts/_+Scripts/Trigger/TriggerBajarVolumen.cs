﻿using UnityEngine;
using System.Collections;

public class TriggerBajarVolumen : MonoBehaviour {

	// Arrastrar aqui la fuente de audio que queremos que baje el volumen
	public AudioSource fuenteDeAudio;

	// Update is called once per frame
	void OnTriggerStay ( Collider infoAcceso ) {

		// Calculamos la distancia al centro de la zona
		Vector3 distancia = transform.position - infoAcceso.transform.position;

		// Calculamos el volumen en funcion de la distancia
		float volumen = 1f - ( 5f - distancia.magnitude ) / 5f;

		// Aplicamos el volumen
		fuenteDeAudio.volume = volumen;

	}

}
