﻿#pragma strict

// Esta funcion se ejecuta automaticamente cuando un colisionador entra dentro
//  de la geometria del trigger que lleva este script
function OnTriggerEnter ( ) {

	// El objeto es destruido
	Destroy ( gameObject );

}