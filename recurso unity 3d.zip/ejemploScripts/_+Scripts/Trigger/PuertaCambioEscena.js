﻿#pragma strict

var destino : int = 2;

// Esta funcion se ejecuta automaticamente cuando un colisionador entra dentro
//  de la geometria del trigger que lleva este script
function OnTriggerEnter ( ) {

	// Se carga el nivel dado por la variable destino
	Application.LoadLevel ( destino );

}