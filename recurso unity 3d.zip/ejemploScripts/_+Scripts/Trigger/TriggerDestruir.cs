﻿using UnityEngine;
using System.Collections;

public class TriggerDestruir : MonoBehaviour {
	
	public string tagComprobar = "Enemigo";
	
	void OnTriggerEnter ( Collider infoTrigger ) {
		if ( infoTrigger.gameObject.tag == tagComprobar ) {
			Destroy ( gameObject );
		}
	}
	
}
