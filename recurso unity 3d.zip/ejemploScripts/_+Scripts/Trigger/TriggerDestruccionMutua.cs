﻿using UnityEngine;
using System.Collections;

public class TriggerDestruccionMutua : MonoBehaviour {
	
	// Update is called once per frame
	void OnTriggerEnter ( Collider infoAcceso ) {
		Destroy ( infoAcceso.gameObject );
		Destroy ( gameObject );
	}
}
