﻿using UnityEngine;
using System.Collections;

public class EventoTrigger : MonoBehaviour {

	// Objeto para asignar desde el interfaz
	public GameObject enemigo;

	// Este metodo se ejecuta automaticamente cuando "algo"
	//  entra dentro de la geometria del trigger
	void OnTriggerEnter ( Collider infoActivador ) {

		print ( "Hola" );

		// Si el objeto que entra en el trigger es el Prota
		if ( infoActivador.gameObject.name == "Protagonista" ) {
			// Activamos el objeto enemigo
			enemigo.SetActive ( true );
		}

	}

}
