﻿// El siguiente script colocado sobre un trigger se encarga de desactivar
//  temporalmente el controlador de personaje y activar una camara para
//  que ejecute una cinematica. Una vez finaliza la cinematica vuelve
//  a reactivar el controlador de personaje

#pragma strict

// Arrastrar aqui la camara y el personaje
public var camara : GameObject;
public var personaje : GameObject;

// Obtendremos aqui acceso al animador de la camara
public var animatorCamara : Animator;

// Obtenemos acceso al animador de la camara
function Start ( ) {
	animatorCamara = camara.GetComponent ( Animator );
}

// El evento de trigger desactiva el personaje y activa la cinematica
function OnTriggerEnter ( ) {
	
	// Activamos/desactivamos cada cosa
	personaje.SetActive ( false );
	camara.SetActive ( true );
	
}

// Comprueba cuando la camara termina la animacion
function Update ( ) {

	// Si la camara no esta activa retornamos
	if ( !camara.activeInHierarchy ) return;
	
	// Obtenemos el estado de animacion y su tiempo
	var infoEstado : AnimatorStateInfo;
	infoEstado = animatorCamara.GetCurrentAnimatorStateInfo ( 0 );
	print ( "Tiempo clip: " + infoEstado.normalizedTime );
	
	// Si la animacion ha terminado activamos/desactivamos cada cosa
	if ( infoEstado.normalizedTime > 1 ) {
		personaje.SetActive ( true );
		camara.SetActive ( false );
		
		// Destruimos el trigger para que no vuelva a suceder
		Destroy ( gameObject );
	}
	
}
