﻿using UnityEngine;
using System.Collections;

public class TriggerInstanciar : MonoBehaviour {

	public GameObject objeto;

	// Update is called once per frame
	void OnTriggerEnter ( ) {
		Instantiate ( objeto , transform.position , transform.rotation );
	}
}
