﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EstaDelante : MonoBehaviour {

	public Vector3 diferencia;
	public GameObject objetivo;
	public bool estaDelante;
	
	// Update is called once per frame
	void Update ( ) {
		diferencia = objetivo.transform.position - transform.position;
		diferencia = transform.InverseTransformDirection ( diferencia );
		estaDelante = diferencia.z > 0;
		
		if(!estaDelante) Debug.Log("Ponte Tapon");

	}
}
