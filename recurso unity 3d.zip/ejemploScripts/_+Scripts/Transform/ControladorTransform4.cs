﻿// Script: ControladorTransform4.cs
// Descripción: Controlador basico de transform teniendo en cuenta el deltaTime y utilizando las variables
//  estaticas de la clase Vector3 para indicar las direcciones. Las teclas se obtienen por eje y se utilizan
//  variables auxiliares Vector3 para guardar el resultado
// Autor: Ivan Garcia Subero
// Fecha: 25.03.14
// Licencia: Dominio público
// Dependencias: Ninguna
// Por hacer: Nada

using UnityEngine;
using System.Collections;

public class ControladorTransform4 : MonoBehaviour {

	public float velocidad = 1f;
	public float giro = 3f;
	
	// Update is called once per frame
	void Update ( ) {

		Vector3 avance = Input.GetAxis ("Vertical") * Vector3.forward * velocidad * Time.deltaTime;
		transform.Translate ( avance );

		Vector3 rotacion = Input.GetAxis ( "Horizontal" ) * Vector3.up * giro * Time.deltaTime;
		transform.Rotate ( rotacion );

	}
}

