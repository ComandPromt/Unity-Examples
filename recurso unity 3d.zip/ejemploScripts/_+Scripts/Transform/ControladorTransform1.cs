﻿// Script: ControladorTransform1.cs
// Descripción: Controlador basico de transform
// Autor: Ivan Garcia Subero
// Fecha: 25.03.14
// Licencia: Dominio público
// Dependencias: Ninguna
// Por hacer: Nada

using UnityEngine;
using System.Collections;

public class ControladorTransform1 : MonoBehaviour {

	public float velocidad = 1f;
	public float giro = 3f;
	
	// Update is called once per frame
	void Update ( ) {

		if ( Input.GetKey ( KeyCode.W ) ) {
			transform.Translate ( 0 , 0 , velocidad );
		}

		if ( Input.GetKey ( KeyCode.A ) ) {
			transform.Rotate ( 0 , -giro ,0);
		}

	}
}

