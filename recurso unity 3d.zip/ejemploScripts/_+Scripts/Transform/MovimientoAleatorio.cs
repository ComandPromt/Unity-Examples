using UnityEngine;
using System.Collections;

public class MovimientoAleatorio : MonoBehaviour {
	
	// Update is called once per frame
	void Update () {
	
		transform.Translate ( 
			Random.Range ( -0.05f , 0.05f ) , 0 ,  Random.Range ( -0.05f , 0.05f ) 
		);
		
	}
}
