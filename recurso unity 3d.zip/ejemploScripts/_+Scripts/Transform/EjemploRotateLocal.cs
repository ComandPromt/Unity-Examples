﻿using UnityEngine;
using System.Collections;

public class EjemploRotateLocal : MonoBehaviour {

	public float velocidadGiro = 60f;
	
	// Update is called once per frame
	void Update ( ) {
		transform.Rotate ( Vector3.up * velocidadGiro * Time.deltaTime , Space.Self );
	}

}
