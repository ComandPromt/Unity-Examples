﻿// Script: ControladorTransform3.cs
// Descripción: Controlador basico de transform teniendo en cuenta el deltaTime y utilizando las variables
//  estaticas de la clase Vector3 para indicar las direcciones
// Autor: Ivan Garcia Subero
// Fecha: 25.03.14
// Licencia: Dominio público
// Dependencias: Ninguna
// Por hacer: Nada

using UnityEngine;
using System.Collections;

public class ControladorTransform3 : MonoBehaviour {

	public float velocidad = 1f;
	public float giro = 3f;
	
	// Update is called once per frame
	void Update ( ) {

		if ( Input.GetKey ( KeyCode.W ) ) {
			transform.Translate ( Vector3.forward * velocidad * Time.deltaTime );
		}

		if ( Input.GetKey ( KeyCode.A ) ) {
			transform.Rotate ( -Vector3.up * giro * Time.deltaTime );
		}

	}
}

