﻿/*  Script: IgualesPeroDistintos.cs
  * Descripción: Script para colocar un objeto de la misma forma en una plano diferente relativo a la camara
  *     de forma que parezca que son iguales a ojos de la camara.
  * Autor: Abel Naya
  * Fecha: 25/03/2014
  * Licencia: Dominio público
  * Por hacer: Nada que yo sepa
  * 
  * 
  * Instrucciones:
  * -Colocar este script en el objeto replicado
  * -añadir a la variable 'referencia' el objeto original
  * -la variable 'd' indica la distancia entre los planos por los que se moveran ambos respecto a la camara,
  * -(no es necesario que la camara este en ninguna posicion especifica)
  * 
  * 
  *        d
  *       ----
  *       |  |
  * 
  *      [#]         <--referencia
  *        \
  *         \
  *         (#)      <--script
  *           \
  *            \
  *             \
  *              >o  <--camara
  * 
  * 
  * 
*/







using UnityEngine;
using System.Collections;

public class IgualesPeroDistintos : MonoBehaviour {
	
	public GameObject referencia;
	public float d = 1;
	
	void FixedUpdate () {
		
		//direccion en la que nos moveremos
		Vector3 direcion = Camera.main.transform.position-referencia.transform.position;
		
		//coseno, lo usaremos mas adelante
		float coseno = Mathf.Cos ( Vector3.Angle (Camera.main.transform.forward,-direcion)*Mathf.Deg2Rad );
		
		//avanzamos hacia la camara tanto como sea necesario
		this.transform.position=referencia.transform.position+direcion.normalized*d/coseno;
		
		//Cambiamos la escala
		//NOTA: solo es necesario hacer el calculo una vez si la escala o 
		        //la distancia a la camara del objeto referencia no cambia
		        //ante la duda dejar que se ejecute siempre
		this.transform.localScale=referencia.transform.localScale*(1-d/direcion.magnitude/coseno);
		
		
		//cambiamos la rotacion, para que sea lo mas realista posible
		this.transform.rotation=referencia.transform.rotation;
		
	}
	
}
