﻿#pragma strict

public var direccion : Vector3;
public var desviacion : float = 10f;

function Update ( ) {

	// Alineamos el objeto con la direccion
	transform.forward = direccion;
	
	// Al pulsar una tecla calculamos una nueva direccion desviada
	if ( Input.anyKeyDown ) {
		direccion = Desviar ( direccion , desviacion );
	}

}

// Dado un vector y unos grados de desviacion, este metodo
//  nos devuelve el mismo vector desviado como maximo esos grados
function Desviar ( vector : Vector3 , cuanto : float ) : Vector3 {

	// Calculamos la nueva direccion (Sin magnitud, con longitud aprox.2)
	var direccion : Vector3 =
			vector.normalized +
			Random.onUnitSphere * Mathf.Sin ( cuanto * Mathf.Deg2Rad );

	// Devolvemos la nueva direccion con la magnitud del vector inicial
	return direccion.normalized * vector.magnitude;
}
