using UnityEngine;
using System.Collections;

public class MovimientoAleatorioXY : MonoBehaviour {

	public float cantidad = 0.1f;

	// Update is called once per frame
	void Update () {
	
		transform.Translate ( 
			Random.Range ( -cantidad*Time.deltaTime , cantidad*Time.deltaTime ) , Random.Range ( -cantidad*Time.deltaTime , cantidad*Time.deltaTime ) , 0  
		);
		
	}
}
