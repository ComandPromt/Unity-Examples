﻿using UnityEngine;
using System.Collections;

public class DadoGenerico : MonoBehaviour {

	public int resultado;
	public int maximo = 6;

	// Update is called once per frame
	void Update ( ) {

		resultado = Random.Range ( 1 , maximo+1 );

	}

}
