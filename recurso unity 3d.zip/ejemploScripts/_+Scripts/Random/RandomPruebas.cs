﻿using UnityEngine;
using System.Collections;

public class RandomPruebas : MonoBehaviour {

	public Vector2 vector2Aleatorio;
	public Vector3 vector3Aleatorio;
	public float radio;
	public bool modo;
	public GameObject cubo;

	// Update is called once per frame
	void Update () {

		if ( Input.anyKeyDown ) {
			modo = !modo;
		}

		if ( modo == true ) {

			// Calculamos un vector3 aleatorio dentro de una esfera
			vector3Aleatorio = Random.insideUnitSphere;
			Instantiate ( cubo , vector3Aleatorio * radio , Random.rotation );

		}

		else if ( modo == false ) {

			// Calculamos un vector3 aleatorio dentro de un cubo
			vector3Aleatorio = new Vector3 ( Random.Range ( -radio , radio ) ,
				Random.Range ( -radio , radio ) , Random.Range ( -radio , radio ) );
			Instantiate ( cubo , vector3Aleatorio , Quaternion.identity );

		}

	}

}
