﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControladorMachineBehaviour : StateMachineBehaviour {

    public GameObject prefabDisparo;
    public bool haDisparado = false;

    void OnStateEnter ( Animator animator, AnimatorStateInfo stateInfo, int layerIndex){
        Debug.Log ( "Entrando en el estado" );
    }

    void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex){
        Debug.Log("Permanencia en el estado " + stateInfo.normalizedTime);

        // Comprobamos si hemos llegado al frame adecuado para disparar
        if ( stateInfo.normalizedTime >= 0.585f) { 

            // Si no ha disparado aún, disparamos y ponemos el bool a true para que sólo pase
            //  una vez.
            if ( ( haDisparado == false ) && Input.GetKey ( KeyCode.Space ) ) {
                Instantiate ( prefabDisparo , animator.transform.position + (Vector3.up*0.5f) ,
                    animator.transform.rotation );
                haDisparado = true;
            }

        }
    }

    void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex){
        Debug.Log ( "Saliendo del estado" );
        haDisparado = false;
    }

    void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) {

    }

}
