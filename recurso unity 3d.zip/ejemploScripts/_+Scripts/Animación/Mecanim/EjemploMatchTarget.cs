﻿using UnityEngine;
using System.Collections;

public class EjemploMatchTarget : MonoBehaviour {

	public Animator controlador;

	public bool andar;
	public bool subir;
	public bool haySubida = false;

	public Transform objetivoAnimacion;

	// Update is called once per frame
	void Update () {

		// Antes de nada, obtenemos la informacion del estado de animacion actual
		AnimatorStateInfo estado = controlador.GetCurrentAnimatorStateInfo ( 0 );

		////////////////////////////////////////////////////////////////////////////////////////
		/// Procesamiento automatico de comportamientos, por ejemplo rascarse si no hacemos nada

		// Contamos para cambiar el estado de quieto a andar y viceversa
		if ( Input.GetAxis ( "Vertical" ) != 0 ) {
			andar = true;
		}
		else {
			andar = false;
		}

		/////////////////////////////
		/// Interpretacion de teclas

		// Con la tecla Espacio, si estamos en una subida, hacemos un MatchTarget en la animacion
		if ( Input.GetKey ( KeyCode.Space ) && haySubida ) {
			subir = true;
			controlador.SetBool ( "Subir" , subir );
		}

		//////////////////////////////////////////////////////////////
		/// Procesamiento cuando se encuentra en un estado determinado

		// Si se trata de el estado Subir aplicamos MatchTarget y no estamos ya en transicion hacemos el match target
		if ( estado.IsName ( "Base Layer.Subir" ) && !controlador.IsInTransition ( 0 ) ) {

			// Aseguramos que no vuelva a entrar en este estado
			subir = false;
			controlador.SetBool ( "Subir" , subir );

			// Indicamos con una mascara que la coincidencia debe ser de posicion (1,1,1) y no de rotacion (0)
			MatchTargetWeightMask mascara = new MatchTargetWeightMask ( Vector3.one , 0f );

			// Durante un intervalo hacemos que coincida la mano, y despues que coincida el pie
			controlador.MatchTarget ( objetivoAnimacion.position , objetivoAnimacion.rotation ,
				AvatarTarget.RightHand , mascara , 0.36f , 0.6f
			);
			controlador.MatchTarget ( objetivoAnimacion.position , objetivoAnimacion.rotation ,
				AvatarTarget.RightFoot , mascara , 0.61f , 0.68f
			);

		}

		//////////////////////////////////////////
		/// Aplicacion de las variables modificadas en el controlador

		controlador.SetBool ( "Andar" , andar );

	}

	// Detectamos triggers, en este caso los de obstaculos que se pueden subir
	void OnTriggerStay ( Collider infoAcceso ) {
		if ( infoAcceso.tag == "Subida" ) {
			haySubida = true;
			print ( "Entramos en " + infoAcceso.name );
			objetivoAnimacion = infoAcceso.transform.root.Find ( "Objetivo" );
		}
	}

	// Detectamos salida de trigger
	void OnTriggerExit ( Collider infoAcceso ) {
		if ( infoAcceso.tag == "Subida" ) {
			haySubida = false;
		}
	}


}
