﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerAnimatorFloat : MonoBehaviour {

	public string tagComprobar = "Player";
	public Animator animator;
	public string nombreParametro;
	public bool sumaValor = true;
	private float valorActual;
	
	// Si permanece en nuestro trigger un objeto con el tag dado
	//  se incrementa/decrementa el valor de la máquina de estados con
	//  el nombre dado
	void OnTriggerStay ( Collider infoAcceso ) {
		if ( infoAcceso.tag != tagComprobar ) return;
		valorActual = animator.GetFloat ( nombreParametro );
		if ( sumaValor ) valorActual += Time.deltaTime;
		else valorActual -= Time.deltaTime;
		animator.SetFloat ( nombreParametro , valorActual );
	}

}
