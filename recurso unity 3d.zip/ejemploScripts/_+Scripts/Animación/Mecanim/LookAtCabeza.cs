﻿using UnityEngine;
using System.Collections;

public class LookAtCabeza : MonoBehaviour {

	public Animator animator;
	public GameObject objetivo;
	public float peso = 0f;

	// Se invoca tras haber calculado todas las IK de los huesos de la animacion
	void OnAnimatorIK ( int layer ) {

		// Reasigna el peso de la animacion de LookAt
		animator.SetLookAtWeight ( peso );

		// Hacemos look at al hacer clic, con un lerp para suavizarlo
		if ( Input.GetMouseButton ( 0 ) ) {
			animator.SetLookAtPosition ( objetivo.transform.position );
			peso = Mathf.Lerp ( peso , 1f , Time.deltaTime );
		}
		else {
			peso = Mathf.Lerp ( peso , 0f , Time.deltaTime );
		}

	}

}
