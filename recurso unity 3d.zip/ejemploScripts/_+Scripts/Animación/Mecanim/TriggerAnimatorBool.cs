﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerAnimatorBool : MonoBehaviour {

	public string tagComprobar = "Player";
	public Animator animator;
	public string nombreParametro;
	
	// Si entra en nuestro trigger un objeto con el tag dado
	//  se pone a true el bool de la máquina de estados con
	//  el nombre dado
	void OnTriggerEnter ( Collider infoAcceso ) {
		if ( infoAcceso.tag != tagComprobar ) return;
		animator.SetBool ( nombreParametro , true );
	}

}
