﻿using UnityEngine;
using System.Collections;

public class ControladorAnimacion2D : MonoBehaviour {

	public SpriteRenderer spriteRenderer;
	public int estado = 0;
	public int graph = 0;
	
	public Sprite [ ] sprites;

	[System.Serializable]
	public class Animacion {
		public int graph_ini;
		public int graph_fin;
		public float tiempo;
	}
	
	public Animacion [ ] animaciones;
	
	// Update is called once per frame
	void Update ( ) {

		// Cambio de estado de animacion
		if ( Input.anyKey ) estado = 1;
		else estado = 0;

		// Ejecucion de la animacion
		spriteRenderer.sprite = sprites [ graph ];
		graph++;

		// Limites de la animacion. Si esta fuera del rango reiniciamos
		if ( graph > animaciones [ estado ].graph_fin ||
		    graph < animaciones [ estado ].graph_ini ) {
			graph = animaciones [ estado ].graph_ini;
		}

	}

}
