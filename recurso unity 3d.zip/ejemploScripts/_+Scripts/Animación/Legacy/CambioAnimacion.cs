using UnityEngine;
using System.Collections;

public class CambioAnimacion : MonoBehaviour {
	
	// Tipo enumerado con los estados que usa el controlador
	private enum Estados { Quieto = 0 , Andar , Atacar , Saltar };
	private Estados estado;
	
	// Variables de control de la animación
	public string [ ] animaciones = new string [ 16 ];
	
	public bool colision = false;
	
	public float fuerzaSalto = 5.0F;
	
	void Start ( ) {
		
		// Obtiene todos los nombres de animación y los memoriza
		int contador = 0;
		foreach ( AnimationState estadoActual in animation ) {
            animaciones [ contador ] = estadoActual.name;
			contador++;
        }
		
		// Comienza asignando la animación de quieto
		estado = Estados.Quieto;
		animation.Play ( animaciones [ (int)estado ] );
		
	}
	
	// Update is called once per frame
	void Update ( ) {
		
		// Máquina de estados de animación
		if ( estado == Estados.Quieto ) {
			if ( Input.GetKey ( KeyCode.W ) || Input.GetKey ( KeyCode.W ) ) {
				estado = Estados.Andar;
			}
			if ( Input.GetMouseButton ( 0 ) ) {
				estado = Estados.Atacar;
			}
			if ( Input.GetKey ( KeyCode.Space ) ) {
				estado = Estados.Saltar;
			}
		}
		
		else if ( estado == Estados.Andar ) {
			if ( ! ( Input.GetKey ( KeyCode.W ) || Input.GetKey ( KeyCode.W ) ) ) {
				estado = Estados.Quieto;
			}
			if ( Input.GetMouseButton ( 0 ) ) {
				estado = Estados.Atacar;
			}
			if ( Input.GetKey ( KeyCode.Space ) ) {
				estado = Estados.Saltar;
			}
		}
		
		else if ( estado == Estados.Saltar ) {
			if ( colision ) {
				estado = Estados.Quieto;
			}
		}
		
		else if ( estado == Estados.Atacar ) {
			if ( animation [ animaciones [ (int)Estados.Atacar ] ].time > 0.9F*(animation [ animaciones [ (int)Estados.Atacar ] ].length) ) {
				estado = Estados.Quieto;
			}
		}
		
		// Asignación de animaciones
		if ( estado == Estados.Quieto ) {
			animation.CrossFade ( animaciones [ (int)Estados.Quieto ] );
		}
		else if ( estado == Estados.Andar ) {
			animation.CrossFade ( animaciones [ (int)Estados.Andar ] );
		}
		else if ( estado == Estados.Atacar ) {
			animation.CrossFade ( animaciones [ (int)Estados.Atacar ] );
		}
		else if ( estado == Estados.Saltar ) {
			animation.CrossFade ( animaciones [ (int)Estados.Saltar ] );
		}
		
		
		// Control de movimiento
		if ( Input.GetKeyDown ( KeyCode.Space ) ) {
			rigidbody.AddForce ( Vector3.up * fuerzaSalto , ForceMode.Impulse );
		}
		
		// Resetea el control de colisión en el salto
		colision = false;
		
	}
	
	// Nos indica si hay colisión, para permitir que salte y para dejar de saltar
	void OnCollisionEnter ( ) {
		colision = true;
	}
	
}
