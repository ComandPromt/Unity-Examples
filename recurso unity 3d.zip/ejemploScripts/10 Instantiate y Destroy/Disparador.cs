﻿using UnityEngine;
using System.Collections;

public class Disparador : MonoBehaviour {

	public GameObject prefabDisparo;
	
	// Update is called once per frame
	void Update () {
		
		if ( Input.GetMouseButtonDown ( 0 ) ) {
			// Clona el prefab del disparo con la misma posición y rotación 
			//  que el objeto que lo dispara
			Instantiate ( prefabDisparo , transform.position , transform.rotation );
		}

	}
}
