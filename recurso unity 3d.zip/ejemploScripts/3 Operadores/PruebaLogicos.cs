﻿using UnityEngine;
using System.Collections;

public class PruebaLogicos : MonoBehaviour {

	public bool interruptor;
	public bool llaveRoja;
	public bool llaveAzul;

	public int vida;

	public bool victoriaNormal;
	public bool victoriaRara;
	
	// Update is called once per frame
	void Update () {

		// Invierte el valor de un booleano
		interruptor = !interruptor;
		print ( interruptor );

		// Activamos victoria sólo si llaveAzul es verdad, llaveRoja es verdad
		//  y además la vida es > 0
		victoriaNormal = llaveAzul && llaveRoja && ( vida > 0 );

		// Activamos victoria rara sólo si llaveAzul es verdad y llaveRoja falsa,
		//  o bien llaveAzul es falsa y llaveRoja verdad
		victoriaRara = ( llaveAzul && !llaveRoja ) || ( !llaveAzul && llaveRoja );

	}
}
