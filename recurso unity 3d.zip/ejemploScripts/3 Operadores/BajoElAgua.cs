﻿using UnityEngine;
using System.Collections;

public class BajoElAgua : MonoBehaviour {

	public bool bajoElAgua;
	public GameObject personaje;
	public GameObject agua;
	
	// Update is called once per frame
	void Update () {
		bajoElAgua = ( personaje.transform.position.y < agua.transform.position.y );
	}

}
