﻿using UnityEngine;
using System.Collections;

public class Perseguir : MonoBehaviour {

	public Vector3 diferenciaPosicion;
	public GameObject objetivo;
	public float velocidad;
	public float distanciaParada;

	void Update () {
	
		// 1. Calculamos el vector diferencia de posición
		diferenciaPosicion = objetivo.transform.position - transform.position;

		// 2. Avanzamos en la dirección de ese vector. Lo multiplicamos por un valor
		//  de velocidad "pequeño" para que no llegue al destino en un sólo frame
		if ( diferenciaPosicion.magnitude > distanciaParada ) {
			transform.position = transform.position + 
				( diferenciaPosicion.normalized * velocidad );
		}
			
		// 3. Rotaremos para mirar en esa dirección. Conociendo la dirección
		//  basta con asignar la forward hacia ella
		transform.forward = diferenciaPosicion.normalized;

	}

}
