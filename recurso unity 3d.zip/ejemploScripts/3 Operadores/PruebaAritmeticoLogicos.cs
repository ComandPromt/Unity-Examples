﻿using UnityEngine;
using System.Collections;

public class PruebaAritmeticoLogicos : MonoBehaviour {

	public bool avisoTemperatura;
	public float temperatura;
	
	// Update is called once per frame
	void Update ( ) {

		temperatura = temperatura + 0.04f;

		// Los operadores aritmético-lógicos trabajan con operandos
		//  numéricos (float, int...) pero generan un resultado BOOL
		// NO se debe usar el operador == entre valores float, son
		//  imprecisos y prácticamente NUNCA son exactamente iguales
		avisoTemperatura = ( temperatura >= 40 );

		// OJO: Ya veremos los condicionales a fondo!!!
		if (avisoTemperatura) {
			print ("LOL");
		}
	
	}

}
