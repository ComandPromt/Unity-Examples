﻿using UnityEngine;
using System.Collections;

public class PruebaAritmeticos : MonoBehaviour {

	public float contadorReal;

	public int contador;
	public int resultadoModulo;

	public float resultadoDivision;
	
	// Update is called once per frame
	void Update () {

		// Ejemplo de aplicación del método Pow de la clase Mathf
		//  para calcular potencias (No hay operador básico para eso)
		contadorReal = Mathf.Pow ( contadorReal , 2 );
		print ( contadorReal );

		// Ejemplo del operador módulo, el contador siempre suma 1,
		//  en resultadoModulo guardamos el RESTO de su división po 10
		contador = contador + 1;
		resultadoModulo = contador % 10;
		print ( resultadoModulo );

		// Ejemplo de división por 0. La división por 0 da ERROR si se
		//  trabaja con int, y da Infinity si se trabaja con float
		resultadoDivision = 1000f / 2f;

	}

}
