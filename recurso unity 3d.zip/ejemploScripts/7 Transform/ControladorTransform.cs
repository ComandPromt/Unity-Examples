﻿using UnityEngine;
using System.Collections;

public class ControladorTransform : MonoBehaviour {

	public float velocidad = 10;
	public float giro;

	public Space espacio;
	public float contador;
	
	// Update is called once per frame
	void Update ( ) {

		// transform.Translate ( 0 , 0 , 1 , Space.Self );
		// transform.Translate ( new Vector3 ( 0 , 0 , 1 ) , Space.Self );
		// transform.Translate ( Vector3.forward , Space.World );

		// transform.Translate ( Vector3.forward * velocidad );
		// transform.Translate ( Vector3.forward * velocidad * Time.deltaTime );

		/* if ( Input.GetKey ( KeyCode.W ) ) {
			transform.Translate ( Vector3.forward * velocidad * Time.deltaTime );
		}
		if ( Input.GetKey ( KeyCode.S ) ) {
			transform.Translate ( Vector3.back * velocidad * Time.deltaTime );
		} */

		// Modo general de trabajo con controladores: eje + dirección + velocidad + deltaTime
		transform.Translate ( Input.GetAxis ( "Vertical" ) *
			Vector3.forward * velocidad * Time.deltaTime );

		// Con deltaTime podemos contar en unidades/segundo
		Debug.Log (Time.deltaTime);
		contador = contador + Time.deltaTime;

	}

}
