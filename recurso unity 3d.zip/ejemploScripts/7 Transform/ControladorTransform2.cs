﻿using UnityEngine;
using System.Collections;

public class ControladorTransform2 : MonoBehaviour {

	public float velocidad = 10;
	public float giro = 90;
	
	// Update is called once per frame
	void Update ( ) {
	
		// Avance FIJO hacia adelante, y otro avance más para el turbo
		transform.Translate ( Vector3.forward * velocidad * Time.deltaTime );
		transform.Translate ( Input.GetAxis ( "Turbo" ) * 
			Vector3.forward * velocidad * Time.deltaTime );

		// Giro según los ejes horizontal y vertical
		transform.Rotate ( Input.GetAxis ( "Vertical" ) *
			Vector3.right * giro * Time.deltaTime );

		transform.Rotate ( Input.GetAxis ( "Horizontal" ) *
			Vector3.up * giro * Time.deltaTime , Space.World );

		transform.Rotate ( Input.GetAxis ( "Lateral" ) *
			Vector3.forward * giro * Time.deltaTime );

	}
}
