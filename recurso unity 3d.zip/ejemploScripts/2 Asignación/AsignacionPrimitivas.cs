﻿using UnityEngine;

public class AsignacionPrimitivas : MonoBehaviour {

	// ZONA DE VARIABLES

	// 1. Variables primitivas, existen en todos los lenguajes de programación
	public int puntosDeVida;
	public float dano;
	public bool tocaSuelo;
	public string nombrePersonaje;

	// ZONA DE MÉTODOS

	// Use this for initialization
	void Start ( ) {
		puntosDeVida = -545;
		dano = -16541.515f;
		tocaSuelo = true;
		nombrePersonaje = "Pedro Picapiedra";
		print ( "El mayor float vale " + float.MaxValue );
	}

}
