﻿using UnityEngine;

public class AsignacionEstructuras : MonoBehaviour {

	// ZONA DE VARIABLES

	// 2. Variables estructura, propias de Unity, son varias primitivas juntas
	public Color colorBarraVida;
	public Color32 colorEn32Bits;
	public Vector2 direccion2D;
	public Vector3 direccion3D;

	// ZONA DE MÉTODOS

	// Use this for initialization
	void Start ( ) {
		colorBarraVida = new Color ( 1 , 0 , 0 ); // Ojo, los canales van entre 0 y 1
		colorEn32Bits = new Color32 ( 87 , 35 , 100 , 0 );
		direccion2D = new Vector2 ( -100 , 100 );
		direccion3D = new Vector3 ( -1000 , 2000 , -5000 );
	}

}
