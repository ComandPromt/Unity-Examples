﻿using UnityEngine;

public class AsignacionComponentes : MonoBehaviour {

	// ZONA DE VARIABLES

	// 4. Variables acceso a componente, hay un tipo por cada componente de Unity
	public Transform posicion;
	public Rigidbody rigidbody;
	public BoxCollider boxCollider;
	public LineRenderer lineRenderer;

	// ZONA DE MÉTODOS

	// Use this for initialization
	void Start ( ) {
		rigidbody = GetComponent<Rigidbody>( );
		boxCollider = GetComponent<BoxCollider>( );
		lineRenderer = GetComponent<LineRenderer>( );
	}

}
