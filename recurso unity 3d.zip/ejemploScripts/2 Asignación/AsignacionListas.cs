﻿using UnityEngine;

public class AsignacionListas : MonoBehaviour {

	// ZONA DE VARIABLES

	// 3. Variables lista
	public KeyCode teclaSalto;
	public LayerMask objetosAtravesar;	// Ésta NO la vamos a asignar por ahora
	public Space espacio;
	public ForceMode modoDeFuerza;
	public HumanBodyBones hueso;

	// ZONA DE MÉTODOS

	// Use this for initialization
	void Start ( ) {
		teclaSalto = KeyCode.Asterisk;
		espacio = Space.World;
		modoDeFuerza = ForceMode.Impulse;
		hueso = HumanBodyBones.RightHand;
	}

}
