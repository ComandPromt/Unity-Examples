﻿using UnityEngine;

public class BarraDeVida : MonoBehaviour {

	// ZONA DE VARIABLES

	public Color colorBarraVida;		// Para almacenar el color actual de la barra de vida
	public float vida;					// Para los contadores de vida y vida máxima
	public float vidaMax;
	public float regeneracion;

	public float canalRojo;				// Para poder ir calculando cada canal de color
	public float canalVerde;
	public float canalAzul;

	public MeshRenderer renderizador;	// Para tener acceso al renderizador y poder cambiar el color de su material


	void Start ( ) {
		vida = Random.Range ( 0 , vidaMax / 2 );
		regeneracion = Random.Range ( 0 , vidaMax / 100 );
	}

	// Calculamos en el Update para que en cada frame se actualice el color
	void Update ( ) {

		// Regeneramos 1 punto de vida en cada frame para poder ver si funciona OK
		vida = vida + regeneracion;
		vida = Mathf.Clamp ( vida , 0 , vidaMax );

		// Calculamos los valores de cada canal en tanto por 1
		canalAzul = 0;
		canalVerde = (float)vida / (float)vidaMax;
		canalRojo = 1 - canalVerde;

		// Asignamos el color resultante
		colorBarraVida = new Color ( canalRojo , canalVerde , canalAzul );

		// CASOS DE ACCESO A COMPONENTE PARA METER LOS VALORES CALCULADOS

		// Accedemos al componente renderizador y le metemos el color a su material
		renderizador.material.color = colorBarraVida;
		// Accedemos al componente transform y le metemos la escala calculada
		transform.localScale = new Vector3 ( canalVerde , 1 , 1 );

	}

}
