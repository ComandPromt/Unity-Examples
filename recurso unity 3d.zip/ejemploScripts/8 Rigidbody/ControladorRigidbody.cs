﻿using UnityEngine;
using System.Collections;

public class ControladorRigidbody : MonoBehaviour {

	public Rigidbody rigidbody;

	public float fuerza;
	public float torsion;
	public float turbo = 10;

	// Se ejecuta una vez en cada frame físico (6 por segundo aprox.)
	void FixedUpdate ( ) {

		// Avance FIJO hacia adelante, y otro avance más para el turbo
		rigidbody.AddRelativeForce ( Vector3.forward * fuerza );
		if (Input.GetKeyDown (KeyCode.Space)) {
			rigidbody.AddRelativeForce ( Vector3.forward * turbo , ForceMode.Impulse );
		}

		// Giro según los ejes horizontal y vertical
		rigidbody.AddRelativeTorque ( Input.GetAxis ( "Vertical" ) *
			Vector3.right * torsion );

		rigidbody.AddTorque ( Input.GetAxis ( "Horizontal" ) *
			Vector3.up * torsion );

		rigidbody.AddRelativeTorque ( Input.GetAxis ( "Lateral" ) *
			Vector3.back * torsion );

	}

}
