﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class TriggerRecargarNivel : MonoBehaviour {

	public string tagComprobar = "Player";
	
	// Update is called once per frame
	void OnTriggerEnter ( Collider infoAcceso ) {
		if (infoAcceso.tag != tagComprobar)
			return;
		SceneManager.LoadScene (SceneManager.GetActiveScene ().buildIndex);
	}
}
