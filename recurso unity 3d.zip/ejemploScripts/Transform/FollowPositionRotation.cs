﻿using UnityEngine;
using System.Collections;

public class FollowPositionRotation : MonoBehaviour {

	public bool followPosition;
	public bool followRotation;

	public GameObject target;

	// Update is called once per frame
	void Update () {
	
		if (followPosition) {
			transform.position = target.transform.position;
		}
		if (followRotation) {
			transform.rotation = target.transform.rotation;
		}

	}
}
