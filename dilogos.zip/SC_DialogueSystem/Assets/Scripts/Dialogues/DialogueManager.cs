﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManager : MonoBehaviour
{
    public GameObject nameObj, dialogueObj,continueObj;

    public TextMeshProUGUI nameText,dialogueText;
    public Animator anim;
    public Queue<string> sentences;
    public Camera cam1,cam2;
    // Start is called before the first frame update
    void Start()
    {
        sentences = new Queue<string>();
    }

    public void StartDialogue(Dialogue dialogue) 
    {
        
       // Debug.Log("Hablando con " + dialogue.name);

        nameObj.SetActive(true);
        dialogueObj.SetActive(true);
        continueObj.SetActive(true);

        anim.SetBool("OpenClose", true);
        
        nameText.text = dialogue.name;

        sentences.Clear();
        foreach (string sentence in dialogue.sentences) 
        {
            sentences.Enqueue(sentence);
        }
        DisplayNextSentence();
        
    }

    public void DisplayNextSentence() 
    { 

        if (sentences.Count == 0) 
        {
            EndDialogue();
            return;
        }
        if (sentences.Count == sentences.Count)
        {
            cam1.depth = 1;
            cam2.depth = 0;
        }

        string sentece= sentences.Dequeue();

       
       // Debug.Log(sentece);

        dialogueText.text = sentece;
    }
    void EndDialogue() 
    {        
        FindObjectOfType<Player>().isTalking = false;
        anim.SetBool("OpenClose", false);
        Debug.Log("Ended");
        cam2.depth = 1;
        cam1.depth = 0;
    }

}
