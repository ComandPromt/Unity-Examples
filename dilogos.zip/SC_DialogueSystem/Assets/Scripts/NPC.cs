﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NPC : MonoBehaviour
{
    public Transform[] pos;
    NavMeshAgent npc;
    public bool canTalk;
    // Start is called before the first frame update
    void Start()
    {
        canTalk = true;
        npc = GetComponent<NavMeshAgent>();
        npc.SetDestination(pos[0].position);
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.x == pos[0].position.x && transform.position.z == pos[0].position.z) {
            npc.SetDestination(pos[1].position);
            return;
        }
        if (transform.position.x == pos[1].position.x && transform.position.z == pos[1].position.z)
        {
            npc.SetDestination(pos[0].position);
            return;
        }
    }
    public void MirarAJugador()
    {
        transform.LookAt(FindObjectOfType<Player>().transform,transform.up);
        
    }
}
