﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Player : MonoBehaviour
{
    Rigidbody rb;
    public float speed;
    public GameObject uiPressTalk;
    public bool isTalking;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void FixedUpdate()
    {
        if (!isTalking)
        {
            rb.velocity = Vector3.forward * speed * Input.GetAxis("Vertical");
            rb.velocity += Vector3.right * speed * Input.GetAxis("Horizontal");
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "NPC") {

            if (other.GetComponent<NPC>().canTalk)
            {
                uiPressTalk.SetActive(true);
                other.GetComponent<NavMeshAgent>().isStopped = true;
            }
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "NPC")
        {
            other.GetComponent<NPC>().MirarAJugador();
            if (other.GetComponent<NPC>().canTalk)
            {                
                if (Input.GetKeyDown(KeyCode.E))
                {
                    other.GetComponent<DialogueTrigger>().TriggerDialogue();
                    other.GetComponent<NPC>().canTalk = false;
                    
                    isTalking = true;
                }
            }
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "NPC")
        {
            
            uiPressTalk.SetActive(false);
            other.GetComponent<NavMeshAgent>().isStopped = false;

        }
    }
}
